-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: westdeli
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_qsynumlpzxcdmstbfunnkfinkduupveccsxg` (`primaryOwnerId`),
  CONSTRAINT `fk_asejmwvvdxzzyyyfrxnyzoaqqbicwiuriecz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qsynumlpzxcdmstbfunnkfinkduupveccsxg` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rzmdrcmjskskfovasjurzffrddwzzojytpxl` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_luafsictqwcrfydmlffglikbzovgsubsambk` (`dateRead`),
  KEY `fk_oaewqltrkimpthqtayqbyjwkxigjzdvhdwza` (`pluginId`),
  CONSTRAINT `fk_jrvwzlbfiyngmbrfoxdmcqkrrbyhrjyaynxy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oaewqltrkimpthqtayqbyjwkxigjzdvhdwza` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zbbgbtdlvratdfaxeicoohggzoxycoglveuv` (`sessionId`,`volumeId`),
  KEY `idx_hzezxbjpxqnggqnemyhvqowmqetvmbnumegy` (`volumeId`),
  CONSTRAINT `fk_uihwlqadarcohosqrynqhcoavzxfewraypvg` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zwwsqeitpaydrwmhhdshcodxqoyurqtkbubu` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jkgravbjednyaqdqpbcipcgmaktrxwhcavef` (`filename`,`folderId`),
  KEY `idx_gentjnokpsygikygfpinvkrohkkmubdkwmgm` (`folderId`),
  KEY `idx_ubbkzdibnvtdpnqonbmckafjctocltayopwi` (`volumeId`),
  KEY `fk_qognygnzjeycwbbycpesjqfpeqvmcrxmkjyx` (`uploaderId`),
  CONSTRAINT `fk_fnusjuhcdvnzpbsvzzvdlhodfecdqveosqvc` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gktdvfvfjkqczzymhuxpubwpgsuzjxrjeyzn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qognygnzjeycwbbycpesjqfpeqvmcrxmkjyx` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vsnbxgfinqyxggautxnmsbfoqeaufstwobjd` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_gygwrwegpwxpbekbzbufcpfwlyrfwxjrtsuq` (`siteId`),
  CONSTRAINT `fk_gygwrwegpwxpbekbzbufcpfwlyrfwxjrtsuq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kmcozqntzqtawrwnezowzvmslkufcokrwzrk` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_gwrqvjifouacmhonyjfiwaetttkagvxlwcio` (`userId`),
  CONSTRAINT `fk_gwrqvjifouacmhonyjfiwaetttkagvxlwcio` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qbyztsokeiqxfnmazarcftkzlgjzgbkzpkpt` (`groupId`),
  KEY `fk_jzwmkyjxmfibbgisuxiywaylzntgtrsvwmni` (`parentId`),
  CONSTRAINT `fk_gblfdlqrsipygnscprkuqoobebeceelvizba` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jzwmkyjxmfibbgisuxiywaylzntgtrsvwmni` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wcjizecnmbgyzgygbeuptdlavhncspmfaaha` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_epkzelougssmhjvzcbmmtlxwbuznnvfjwyrh` (`name`),
  KEY `idx_pmlrknlydjzxwvquooxrqskfpibccfbswhsk` (`handle`),
  KEY `idx_uouzknfihbrwttazbxbttvrsmarjekwcoqfy` (`structureId`),
  KEY `idx_ywubjvwnkfxoabgztihgsoyikwvxrbliewzg` (`fieldLayoutId`),
  KEY `idx_zghfvnwcfpscgpasggvhcqvflohqttfrsanf` (`dateDeleted`),
  CONSTRAINT `fk_aailpcbkhfwdytfmzgfwfeektmmnttayaoer` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_omwlvdpfasimslumfyvjcrlnfdlbtroyoliz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zohqfqiimfcypqkuqnmwahbvuundnnysfubq` (`groupId`,`siteId`),
  KEY `idx_rrwwrkirnnkgcpbsvxhsimenblbucqsqeapp` (`siteId`),
  CONSTRAINT `fk_vricdradigrcsxkkpmffdhzpdlbfxwuovpcc` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymlhxijcriwghtrxvkjygizftpdubipscozr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_wmsyasrtigsqpuffhznmyamiiaolibzkhyfu` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_utwnteijredmqyvhokassgikywpmiefossyi` (`siteId`),
  KEY `fk_mapflxfnxxmachnyyjwrbmxfbznxeamnidnx` (`userId`),
  CONSTRAINT `fk_mapflxfnxxmachnyyjwrbmxfbznxeamnidnx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ncbyvywzsnfgrvzzalhmgkbddeuzzoykpzhs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_utwnteijredmqyvhokassgikywpmiefossyi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_hsdqzrovnrcbqidayondavbhnmayhnykoxto` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_acmtbsdfweytnnnobikxtvpjngdlpnektmsa` (`siteId`),
  KEY `fk_waybxmatgyknribjhkjpxjhzrnvsweeadzcq` (`fieldId`),
  KEY `fk_uylpyiswuciyumermtrnoydjfeukrjqrmpvo` (`userId`),
  CONSTRAINT `fk_acmtbsdfweytnnnobikxtvpjngdlpnektmsa` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qskqcvewibxxrceetqteufitsrpeygipzlsx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uylpyiswuciyumermtrnoydjfeukrjqrmpvo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_waybxmatgyknribjhkjpxjhzrnvsweeadzcq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_xexjkvwjgbbwmksuijtvktxunfydbhkpehmc` (`userId`),
  CONSTRAINT `fk_xexjkvwjgbbwmksuijtvktxunfydbhkpehmc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fafdfeqeokuafjahidbenbhhzdviarijmuwn` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_jrkususmtqhkwaseobyiqesvkvwmrvpbnjdl` (`creatorId`,`provisional`),
  KEY `idx_womctonypbrjypkwvstytxpnyosevhpcymmb` (`saved`),
  KEY `fk_vpmiesoczhxdrghsumsqffzybxmhhafodoms` (`canonicalId`),
  CONSTRAINT `fk_vpmiesoczhxdrghsumsqffzybxmhhafodoms` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vtvtyvjtdfaaicnefpbkmmkpqxezqrmkhffd` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_usxkxfeulvkdzvopjyqrilxiwvywaxwadleu` (`elementId`,`timestamp`,`userId`),
  KEY `fk_lxhgumqhedtzgmvqveaouqtmhqdsjwlnejsb` (`userId`),
  KEY `fk_zssrzljhytgyxopqhxhyuooytxydtskjsaxr` (`siteId`),
  KEY `fk_tfoaauquametauusbbazaiakzsmmnufmzhff` (`draftId`),
  CONSTRAINT `fk_lxhgumqhedtzgmvqveaouqtmhqdsjwlnejsb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rdybwqylqbyvmobjoemvqshtazpimddhtwrj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tfoaauquametauusbbazaiakzsmmnufmzhff` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zssrzljhytgyxopqhxhyuooytxydtskjsaxr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wbmcgrghglpojhrrnwthncutbxrobqbngfzm` (`dateDeleted`),
  KEY `idx_fdnytbwcqabrmrpvrxmxaztfrqaufprzczoa` (`fieldLayoutId`),
  KEY `idx_nagifeyfikkhxmlrdxbgtoicketqahbwtyce` (`type`),
  KEY `idx_yattnmbuvjklocfkmathlcdphnaebmdpznai` (`enabled`),
  KEY `idx_fqgupeuqakjkvrjkkgpmldjtbigmyqkggxpt` (`canonicalId`),
  KEY `idx_omlamdldbwduiaplwjjggexeetkkxdcixrms` (`archived`,`dateCreated`),
  KEY `idx_cqibvtgrudqbgdpscixlvtsdrxusbvhugsyt` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_zyncwhyriiwakgztlovzvxfxqujzpzotutzm` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_txfyfnegqvgjsfiolonenstnvrhulogxswkc` (`draftId`),
  KEY `fk_jeluenqryaknfvcqkgsotsolmbvwdmvyence` (`revisionId`),
  CONSTRAINT `fk_fzvnwmxlqtfwckmrnbcxtzwxnhmypzihqlvd` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jeluenqryaknfvcqkgsotsolmbvwdmvyence` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_txfyfnegqvgjsfiolonenstnvrhulogxswkc` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zgquijipqiqahjhnbinxmmeqoehkhvpyzakl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_xmmcibxylgtkurtchprxdzcbtslivkvgomyq` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_tgzhpqatkdigqaykgyjscjlusbbxgbbvaecx` (`ownerId`),
  CONSTRAINT `fk_gyweswbjcosnighndpxsbiunxvbepjpnrqbu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tgzhpqatkdigqaykgyjscjlusbbxgbbvaecx` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wmparqfzrzvumgdqdumtpryabejzrvllvvuw` (`elementId`,`siteId`),
  KEY `idx_nicmqfbvfqqymdetqnbefdcxrdwzfseqroxf` (`siteId`),
  KEY `idx_ehxsiwcpyoliwftseozhlvbgoxzkkxnybisu` (`title`,`siteId`),
  KEY `idx_fofxigvlgmskvkdhysnxqwdlphexhaubsuki` (`slug`,`siteId`),
  KEY `idx_bzediisiiomkspvyzmqwqcahxrwferkydqac` (`enabled`),
  KEY `idx_stfjtqoznonuibaixjhchnfipjafwkyudyxf` (`uri`,`siteId`),
  CONSTRAINT `fk_imogklpdtvywodarmpnfalpmfemajwwbfahk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjwjtzxqxhdgwbszeqlgfakpeyroswjlorwf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gxvtwxtxejfkemxnbufszzygsguxgistmwwj` (`postDate`),
  KEY `idx_snalmasxaqwfpwkqrwbhwsgtmwtvhwxguzxw` (`expiryDate`),
  KEY `idx_fehegbzntswtmcbcgufwoeamqwzwdxsdpyjk` (`sectionId`),
  KEY `idx_ljvtcurteylwyjbonuezkfdvtnwcszdpgjti` (`typeId`),
  KEY `idx_ymimmmcgbqrjoahimuixdwsqxeleojnllvoh` (`primaryOwnerId`),
  KEY `idx_jiighwbfsgosbtfavsxwwguqtrhmkvmjgwaw` (`fieldId`),
  KEY `fk_pkiyjvdgdujgetnpguizwftqkgloazswzhhp` (`parentId`),
  CONSTRAINT `fk_aobxkwmozfoceyzrsgvxhxvcslvnngflahmp` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bkpwodigxuxgfsenpyjbphphcuirgaakkhmf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pkiyjvdgdujgetnpguizwftqkgloazswzhhp` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ppuynxlexlkclrctgjcejdjlupjfdcjgabjn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wyvcxgrlrqyhnmjujrkqjcbuiotfokdsazsw` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xzcbfuntfmxnsaxshqjrdpzsptpqtbhaucqf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_pqyvecgwnxktwqymmxllpgwsoyvzcyovyazs` (`authorId`),
  KEY `idx_nnszvfwpftqqvwkryfxhrqimbzxzrdosdhjj` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_duzipxtkduardkfmwwxhibloajxceiaoorgj` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qjazkuhljbbrihhtuxhifsifwqeesfmtusqc` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nbkxvynpbzmcvilpuntrsptbxqmpkdovrdab` (`fieldLayoutId`),
  KEY `idx_yxezwxkgzgqhmmweeijhcczpmyajciztsxbc` (`dateDeleted`),
  CONSTRAINT `fk_wgpafxmaobuylcnutnlxdgledafzfyetiwgb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kxmtjmiekewqkajqonvfuhwcrueqhumrjsqw` (`dateDeleted`),
  KEY `idx_lscrqptuwqandpsdolavgioatgaalyuqybkx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gitsrqddrzeerbyatdxdraawwvfhndukotcl` (`handle`,`context`),
  KEY `idx_ndfjrejwhqxyieqllvecxfoghjddrkjtspgp` (`context`),
  KEY `idx_zjvcnlqdkxutprqurrltfzoyrxbcjcatrlfe` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qgmmeozuzvhdeaspppgkyrnrhhhnsnukzkdr` (`name`),
  KEY `idx_qpiwueewrhbxwqmuplcepbpsngjbmkjlygfj` (`handle`),
  KEY `idx_rkyeviglregkcwtjsuzuvufqnyesgbxjqxpa` (`fieldLayoutId`),
  KEY `idx_mfiqozzsxdhfgoodzhagrhpaqgfetsjncmjv` (`sortOrder`),
  CONSTRAINT `fk_ihjbcgmmhlyqojrhsppxkufdigvpkuiveclf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tgknddvsauciqpyztzdsqbklwlyggxipkyjj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ipvlmkvwcmxxaqdpsebcjigsnuxwalfoqtxx` (`accessToken`),
  UNIQUE KEY `idx_rjqqhvdumcldytguhitorcclubdnyjgxtryq` (`name`),
  KEY `fk_pbjauyvnrvfjficnqkqnuhacyvpfcaexfuqz` (`schemaId`),
  CONSTRAINT `fk_pbjauyvnrvfjficnqkqnuhacyvpfcaexfuqz` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nxozvtzspvuyhpcmrnjdtdpylasyqdniuwoz` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jqocwyqbxxgrkxijvtmxxyxrofokeyefcshz` (`name`),
  KEY `idx_oodfscbtocplmhczepgtdejzxibdwkxfhaiy` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lrhyvmjqfbauepthpluxcwytyfhwqikqjtnl` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_djhesucvycnfiaknojxlzwkdwscjpqvdddux` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_vxvwiivrmiyazflqzhlkuqiylatqbkbekzal` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_mgjtxlicpkreizsqqxuxjthhtotmaoffsxgs` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_azaszmalqdsmelstokwwmbkqnkxeuwajyuyr` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ojdbfphxoetaioirsgfzfrlicprijebsptaf` (`sourceId`),
  KEY `idx_cshfmqcrkwlhhhtatgdrxbsgcxaiqgoytnln` (`targetId`),
  KEY `idx_fsmhivjpxmnpaclymbbtdlyawqhnzktnhkws` (`sourceSiteId`),
  CONSTRAINT `fk_cbdeepaiyqamqmnggcynexgztkscjjlzfiin` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_crskucsuhblqovytghepjyrddezzpbsxvhkb` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gtqfoiikkjvilfieiknfnuphsawbebwieevu` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rypzejxeioznsvcokxeiwbnydkimphenspve` (`canonicalId`,`num`),
  KEY `fk_tarwqgkqlnkrbkpqnjgbxrtylqqbrlengavu` (`creatorId`),
  CONSTRAINT `fk_tarwqgkqlnkrbkpqnjgbxrtylqqbrlengavu` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tvlktgdmwjldduyysoxfotrgyjnxrfyagxld` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_njalddbgxmktwhzwjetucujevrcxhbjxpuem` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ewjkannpkdrwnnqfaotnxsyoqvplemqydtcv` (`handle`),
  KEY `idx_duujfrdnmwdrdqgcfiwmpbnofmjjmgznjygx` (`name`),
  KEY `idx_wbjzaandsdvmuntdvhtjuzekjknyztxvnlqq` (`structureId`),
  KEY `idx_cqwadgqlqpmovwfrahxpfwetnznewibjauox` (`dateDeleted`),
  CONSTRAINT `fk_ipwhgiiiyutxhozglrgrkahixlhhmudyoxtr` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_tejwejbdwjvcenazprftaagczoddlxxmvtai` (`typeId`),
  CONSTRAINT `fk_epbqydxrwhjmuflbsmchhuksrbosdapvipgi` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tejwejbdwjvcenazprftaagczoddlxxmvtai` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qtrfgayqylsxmyzvkfcjseuhtibgyayoinvd` (`sectionId`,`siteId`),
  KEY `idx_wrmwkcaszlqxkmyropbynekuncxmzhmckfqk` (`siteId`),
  CONSTRAINT `fk_qwozxmdapdrdsohchfqbyhswezakmrkiefvw` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wlylautcbfweqyzrohdjuiwbqaevilwdafiq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ndkuqdtvlrqwuxuajmrxcskfxqckyerwbbgw` (`uid`),
  KEY `idx_toqoqzrsvqiquqcjcnhkacmtarbibkiyhlpk` (`token`),
  KEY `idx_xdepvzkrnecaslmxrqmgqyexndcpkzvuwfqd` (`dateUpdated`),
  KEY `idx_kvpnksuimftqityljgqwcsytmuxxjdvjfwsc` (`userId`),
  CONSTRAINT `fk_esvpcqnnlbmecfpwrlhguuofbgddqjrkermm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hdxlqwnjpijzdpbnwcxtugyfsnpuufgoiiiy` (`userId`,`message`),
  CONSTRAINT `fk_sflspgnicfkuivpacttpmblewhixmzrrqumn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_biiiueafyxbryeqneqhmnmeigrxahdwlmbof` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vgubjtzulbgaerdvhseaiqprlkbibimksxvf` (`dateDeleted`),
  KEY `idx_bwfiopanbwemrirprknhevctojygbtkxcoiw` (`handle`),
  KEY `idx_uvufpsqgjyfajnmofqsflofvwbdokqjukzxh` (`sortOrder`),
  KEY `fk_trgtnmkuxdjgvmwpijpnieoiolzgpbuuybzi` (`groupId`),
  CONSTRAINT `fk_trgtnmkuxdjgvmwpijpnieoiolzgpbuuybzi` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_cytcmnmdbfvsdcktgqgitxeiomahlvceefob` (`userId`),
  CONSTRAINT `fk_cytcmnmdbfvsdcktgqgitxeiomahlvceefob` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jkucikuifxdrjqdyrjelllffkfmrehziajzo` (`structureId`,`elementId`),
  KEY `idx_dpmusotxzymcfsnjvytvnsoryrfkcwnnoxfi` (`root`),
  KEY `idx_wezbpimtnjvkkfgvojtutjsvqxfqexxkmpns` (`lft`),
  KEY `idx_yaympknzeinlxtawgmlycszvowqwizrcqsxa` (`rgt`),
  KEY `idx_acmgprpmyvtzhjujfjaagcevhubbzdfwxxpd` (`level`),
  KEY `idx_ydliypjzzezjmuuqeddvhudwhjqhlwqwmaty` (`elementId`),
  CONSTRAINT `fk_emabgjjqcygyoqmuctkrgkgsvzfaojixdyem` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tfqndfvsokvfckghqdtrxzzrcxunpdcosffy` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_soqcfwlafizlwfxjjntjuaqstxqhfegbpwmx` (`key`,`language`),
  KEY `idx_nmgmlyxfifghbjeruwlshurmjhchfoilonot` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pvkzrhkfxmzlxqzfurvtikyitoxuhlhbugag` (`name`),
  KEY `idx_ckxmtsrobkuebhejpyqpfixruvdlrgwllwjj` (`handle`),
  KEY `idx_jwaieclwzbfxnlrovwqnrsjwcpomoyuojwaj` (`dateDeleted`),
  KEY `fk_okzqtqbxjjlymmfgyblqaqsijmdjxokwsopf` (`fieldLayoutId`),
  CONSTRAINT `fk_okzqtqbxjjlymmfgyblqaqsijmdjxokwsopf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bcnieqzirvfjiqxqpifhhghmjmyehvuhikst` (`groupId`),
  CONSTRAINT `fk_kzakohbotxjukzjdtishbkjoqnjehgbevjon` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wqwycaxbuqmapwriyyhqgdmcnmpbfzedobuu` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_imvakxrvqodasfnpjqduspaaqvlwfctgokru` (`token`),
  KEY `idx_zpgafrfagztgbgdnafnfnwyedvfykqugiiiw` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vxgxyexvowjgqsqwimyqpwleucrwraabmwqv` (`handle`),
  KEY `idx_amhbputyukxdrqamnnapoyngkzgevaedgspm` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aqagzbgruffakhtoccbhmujthwibctfyasem` (`groupId`,`userId`),
  KEY `idx_bneamwiatckpbrewkjwuzyoezypiksglhtjv` (`userId`),
  CONSTRAINT `fk_yangylmjscozswtdsyqpskfnihwjrupjvmlf` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yohtvltrkodzrjzjiwfhntkydyvkriznvffl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iwtafducwernjskxzvlewzvaphpucwnxkubu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xnfqycuzcwhmghmhktmvgahrqyetgworjhwj` (`permissionId`,`groupId`),
  KEY `idx_prwavvnzcwdvbrtbfbgdcvkgcribipdxwtxh` (`groupId`),
  CONSTRAINT `fk_kukxtzqbgsnbtfcucuwkmxuqzwvirrjwqevi` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rarndpvjajqmgpndlmirpcmwgwyogjcjbdjb` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cabdlhizpsxtrpeoaasginyiyjomboicrckn` (`permissionId`,`userId`),
  KEY `idx_oluiizmycygsafdbarnqtymvqosbbpdaopfo` (`userId`),
  CONSTRAINT `fk_iditrwcxzggvaxjfhtbptwflzktsiotbpsiw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_utxmkuxwqxlwipracrbmlslwxrpfejntjzvo` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_kdzqannmtlirehomdxqtglqpyyjvommzavvz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rzplgcgniweopdrpihuhcrwfnneehfianzki` (`active`),
  KEY `idx_mtvuhnsckniqrbnftsqosywgrlykencnjody` (`locked`),
  KEY `idx_txynmcsowplsiiuefwsneixekvncsmwvddcq` (`pending`),
  KEY `idx_abrqcgvupbybeunnbuutgbvlsoqfjzktuick` (`suspended`),
  KEY `idx_sqkgibqhegnwkkvnklwaircezmxwbmbocubc` (`verificationCode`),
  KEY `idx_vjngmvwnhyfvlycazcqixhuauukvqboubleh` (`email`),
  KEY `idx_qkbxrjayoqfpejjadbrebnzvqmldontrjhgl` (`username`),
  KEY `fk_gcervaohhblpenlnoffyescktbvvczmgkoop` (`photoId`),
  CONSTRAINT `fk_bkobnnfrboxnsrrdthksgvppohcdrkbnujtv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gcervaohhblpenlnoffyescktbvvczmgkoop` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_acidiijfpruvkgerwsrjsiaklpbukzdenrks` (`name`,`parentId`,`volumeId`),
  KEY `idx_xhxhhtquoccirzcrhqgaygpkiamvaofcqfol` (`parentId`),
  KEY `idx_loybrjkccvkhqnvekvygawnapkzoynzlgeyu` (`volumeId`),
  CONSTRAINT `fk_anxsnahsgbkapydfpefjuydwyoyvacsxwtbw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fvtvenreikveieskljqamjpgwziscehacfyt` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nswjamrwuhauasfwiftkrmykehzbibpaqmzb` (`name`),
  KEY `idx_jichhlyzrnioeponlfghdnpatkrirmrylvmb` (`handle`),
  KEY `idx_okgmvvenojbwzhbhxdwqipuysdabhkigrrwz` (`fieldLayoutId`),
  KEY `idx_tcvmvvsruwtndbrgrsanvbhkqxklnfnlupwe` (`dateDeleted`),
  CONSTRAINT `fk_codgyhuayzoubtdliykqqskuhjuniipamtzr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_tapdpfjovakqxqnmfltnysilbalkmfscznju` (`userId`),
  CONSTRAINT `fk_tapdpfjovakqxqnmfltnysilbalkmfscznju` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qpcbjgabddnivfklgzoiphukgigeqrrorobr` (`userId`),
  CONSTRAINT `fk_kpiuraxdliiovawylmkjzhhtembclhqevggs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'westdeli'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-26  1:06:38
-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: westdeli
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (3,1,'postDate','2024-10-23 02:10:37',0,1),(3,1,'slug','2024-10-23 19:06:38',0,1),(3,1,'title','2024-10-23 19:06:27',0,1),(3,1,'uri','2024-10-23 02:10:34',0,1),(18,1,'title','2024-10-23 03:55:46',0,1),(22,1,'postDate','2024-10-23 03:01:27',0,1),(22,1,'slug','2024-10-23 19:25:32',0,1),(22,1,'title','2024-10-23 19:25:32',0,1),(22,1,'uri','2024-10-23 03:00:52',0,1),(23,1,'postDate','2024-10-23 03:01:06',0,1),(23,1,'slug','2024-10-23 03:00:59',0,1),(23,1,'title','2024-10-23 03:00:59',0,1),(24,1,'postDate','2024-10-23 03:01:23',0,1),(24,1,'slug','2024-10-23 03:01:16',0,1),(24,1,'title','2024-10-23 03:01:16',0,1),(30,1,'postDate','2024-10-23 03:16:30',0,1),(30,1,'slug','2024-10-23 03:07:57',0,1),(30,1,'title','2024-10-25 17:17:57',0,1),(30,1,'uri','2024-10-23 03:07:57',0,1),(31,1,'postDate','2024-10-23 03:08:13',0,1),(31,1,'slug','2024-10-23 03:08:07',0,1),(31,1,'title','2024-10-23 03:08:07',0,1),(36,1,'title','2024-10-25 23:18:34',0,1),(167,1,'postDate','2024-10-25 17:19:51',0,1),(167,1,'slug','2024-10-25 17:18:42',0,1),(167,1,'title','2024-10-25 17:18:42',0,1),(167,1,'uri','2024-10-25 17:18:42',0,1),(168,1,'postDate','2024-10-25 17:19:04',0,1),(168,1,'slug','2024-10-25 17:18:53',0,1),(168,1,'title','2024-10-25 17:18:53',0,1),(169,1,'postDate','2024-10-25 17:19:26',0,1),(169,1,'slug','2024-10-25 17:19:13',0,1),(169,1,'title','2024-10-25 17:19:13',0,1),(170,1,'postDate','2024-10-25 17:19:46',0,1),(170,1,'slug','2024-10-25 17:19:40',0,1),(170,1,'title','2024-10-25 17:19:40',0,1),(175,1,'postDate','2024-10-25 17:23:49',0,1),(175,1,'slug','2024-10-25 17:20:43',0,1),(175,1,'title','2024-10-25 17:20:43',0,1),(175,1,'uri','2024-10-25 17:20:43',0,1),(176,1,'postDate','2024-10-25 17:21:11',0,1),(176,1,'slug','2024-10-25 17:20:58',0,1),(176,1,'title','2024-10-25 17:20:58',0,1),(177,1,'postDate','2024-10-25 17:21:37',0,1),(177,1,'slug','2024-10-25 17:21:31',0,1),(177,1,'title','2024-10-25 17:21:31',0,1),(178,1,'postDate','2024-10-25 17:22:19',0,1),(178,1,'slug','2024-10-25 17:22:06',0,1),(178,1,'title','2024-10-25 17:22:06',0,1),(179,1,'postDate','2024-10-25 17:22:40',0,1),(179,1,'slug','2024-10-25 17:22:33',0,1),(179,1,'title','2024-10-25 17:22:33',0,1),(180,1,'postDate','2024-10-25 17:23:14',0,1),(180,1,'slug','2024-10-25 17:22:56',0,1),(180,1,'title','2024-10-25 17:22:56',0,1),(181,1,'postDate','2024-10-25 17:23:46',0,1),(181,1,'slug','2024-10-25 17:23:35',0,1),(181,1,'title','2024-10-25 17:23:35',0,1),(189,1,'title','2024-10-25 23:19:52',0,1),(199,1,'title','2024-10-26 00:13:29',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (3,1,2,'97790231-f908-4849-9a4e-335d4b223668','2024-10-23 19:15:00',0,1),(8,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-23 02:11:56',0,1),(18,1,3,'ccc30ff8-d5b2-412e-a7f6-9dafa9edf118','2024-10-25 23:21:06',0,1),(22,1,2,'97790231-f908-4849-9a4e-335d4b223668','2024-10-23 19:35:25',0,1),(23,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-23 03:01:05',0,1),(24,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-23 03:01:21',0,1),(30,1,2,'97790231-f908-4849-9a4e-335d4b223668','2024-10-23 19:31:09',0,1),(31,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-23 03:08:13',0,1),(36,1,3,'ccc30ff8-d5b2-412e-a7f6-9dafa9edf118','2024-10-26 00:54:36',0,1),(167,1,2,'97790231-f908-4849-9a4e-335d4b223668','2024-10-25 17:19:51',0,1),(168,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:19:03',0,1),(169,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:19:25',0,1),(170,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:19:46',0,1),(175,1,2,'97790231-f908-4849-9a4e-335d4b223668','2024-10-25 17:23:49',0,1),(176,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:21:09',0,1),(177,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:21:37',0,1),(178,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:22:18',0,1),(179,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:22:39',0,1),(180,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:23:11',0,1),(181,1,1,'f865dbb8-bcf3-4e15-a2e0-9c282572df60','2024-10-25 17:23:45',0,1),(189,1,3,'ccc30ff8-d5b2-412e-a7f6-9dafa9edf118','2024-10-25 23:19:52',0,1),(199,1,3,'ccc30ff8-d5b2-412e-a7f6-9dafa9edf118','2024-10-26 00:13:42',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (3,1,1,NULL,'edit','2024-10-23 19:14:07'),(3,1,1,NULL,'save','2024-10-23 19:15:00'),(8,1,1,NULL,'edit','2024-10-23 02:11:54'),(8,1,1,NULL,'save','2024-10-23 02:11:56'),(18,1,1,NULL,'edit','2024-10-25 23:21:04'),(18,1,1,NULL,'save','2024-10-25 23:21:06'),(22,1,1,NULL,'edit','2024-10-23 19:31:54'),(22,1,1,NULL,'save','2024-10-23 19:35:25'),(23,1,1,NULL,'save','2024-10-23 03:01:07'),(24,1,1,NULL,'save','2024-10-23 03:01:23'),(30,1,1,NULL,'edit','2024-10-25 17:17:49'),(30,1,1,NULL,'save','2024-10-25 17:17:57'),(31,1,1,NULL,'save','2024-10-23 03:08:13'),(36,1,1,NULL,'edit','2024-10-26 00:54:15'),(36,1,1,NULL,'save','2024-10-26 00:54:36'),(167,1,1,NULL,'save','2024-10-25 17:19:51'),(168,1,1,NULL,'save','2024-10-25 17:19:04'),(169,1,1,NULL,'save','2024-10-25 17:19:26'),(170,1,1,NULL,'save','2024-10-25 17:19:46'),(175,1,1,NULL,'save','2024-10-25 17:23:49'),(176,1,1,NULL,'save','2024-10-25 17:21:11'),(177,1,1,NULL,'save','2024-10-25 17:21:37'),(178,1,1,NULL,'save','2024-10-25 17:22:19'),(179,1,1,NULL,'save','2024-10-25 17:22:40'),(180,1,1,NULL,'save','2024-10-25 17:23:14'),(181,1,1,NULL,'save','2024-10-25 17:23:46'),(189,1,1,NULL,'edit','2024-10-25 23:19:51'),(189,1,1,NULL,'save','2024-10-25 23:19:52'),(199,1,1,NULL,'edit','2024-10-26 00:13:41'),(199,1,1,NULL,'save','2024-10-26 00:13:42');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-10-22 23:54:39','2024-10-22 23:54:39',NULL,NULL,NULL,'743868f8-b0fd-46b2-b2a2-13110f955093'),(2,NULL,1,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-23 02:10:16','2024-10-23 02:10:16',NULL,NULL,NULL,'2dcb6fa2-700e-460b-afaa-2ea089c253b2'),(3,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-23 02:10:16','2024-10-23 19:15:00',NULL,NULL,NULL,'4ecdac44-eba4-4836-94e9-29563c5109b4'),(5,3,NULL,1,2,'craft\\elements\\Entry',1,0,'2024-10-23 02:10:37','2024-10-23 02:10:37',NULL,NULL,NULL,'cfa2e915-e2e9-4d98-8502-c21aefbf1b84'),(8,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 02:11:12','2024-10-23 19:06:27',NULL,'2024-10-23 19:06:27',NULL,'ab3bb11a-770d-4f0b-8240-5ce477461bbe'),(9,3,NULL,2,2,'craft\\elements\\Entry',1,0,'2024-10-23 02:11:12','2024-10-23 02:11:12',NULL,NULL,NULL,'e0bb62df-cafe-492a-8a79-2c8abcee987c'),(10,8,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-10-23 02:11:12','2024-10-23 02:11:12',NULL,'2024-10-23 19:06:27',NULL,'c418a94e-ce70-423e-9496-2b10a89d8f88'),(14,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 02:12:23','2024-10-23 19:06:27',NULL,'2024-10-23 19:06:27',NULL,'c4310de5-7ceb-4362-9cc8-fccf0e22c284'),(15,3,NULL,4,2,'craft\\elements\\Entry',1,0,'2024-10-23 02:12:23','2024-10-23 02:12:23',NULL,NULL,NULL,'33d2642a-ee20-43e1-9a7f-5ba4862d35e6'),(16,8,NULL,5,1,'craft\\elements\\Entry',1,0,'2024-10-23 02:12:23','2024-10-23 02:12:23',NULL,'2024-10-23 19:06:27',NULL,'3e524a70-aab0-4277-9973-088f34647b5b'),(17,14,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-10-23 02:12:23','2024-10-23 02:12:23',NULL,'2024-10-23 19:06:27',NULL,'b209c7a8-8e55-4454-af98-f4947e3bcf56'),(18,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-23 02:30:22','2024-10-25 23:21:06',NULL,NULL,NULL,'c9e649e3-8aa0-491c-bd2b-1cd2cb99aead'),(19,18,NULL,7,3,'craft\\elements\\Entry',1,0,'2024-10-23 02:30:22','2024-10-23 02:30:22',NULL,NULL,NULL,'d2bec70d-3c57-4357-b622-c7f326fda979'),(21,18,NULL,8,3,'craft\\elements\\Entry',1,0,'2024-10-23 02:31:10','2024-10-23 02:31:10',NULL,NULL,NULL,'14e69435-d482-4c56-82a4-497e0692b7d7'),(22,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-23 03:00:20','2024-10-23 19:35:25',NULL,NULL,NULL,'bfda82e2-0a65-4d57-8254-405befb3b64e'),(23,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 03:00:53','2024-10-23 19:25:32',NULL,'2024-10-23 19:25:32',NULL,'df8ece34-c17e-46ae-a0b6-fba032b7d384'),(24,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 03:01:09','2024-10-23 19:25:32',NULL,'2024-10-23 19:25:32',NULL,'7f96d29b-c408-4e93-b2e9-86ba2e80a8a4'),(25,22,NULL,9,2,'craft\\elements\\Entry',1,0,'2024-10-23 03:01:27','2024-10-23 03:01:27',NULL,NULL,NULL,'3ec3cdb3-cf13-4990-b6b6-0727478d1a53'),(26,23,NULL,10,1,'craft\\elements\\Entry',1,0,'2024-10-23 03:01:27','2024-10-23 03:01:27',NULL,'2024-10-23 19:25:32',NULL,'50bd4e05-188c-4080-a893-749eeb7cb229'),(27,24,NULL,11,1,'craft\\elements\\Entry',1,0,'2024-10-23 03:01:27','2024-10-23 03:01:27',NULL,'2024-10-23 19:25:32',NULL,'5142aa22-871d-4c2d-935b-de81312d4759'),(29,18,NULL,12,3,'craft\\elements\\Entry',1,0,'2024-10-23 03:02:37','2024-10-23 03:02:37',NULL,NULL,NULL,'cd9cb60b-c1d7-4e52-ae26-52565224fa6d'),(30,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-23 03:07:49','2024-10-25 17:17:57',NULL,NULL,NULL,'3c8f480b-cf4b-4c8d-8122-be32e154e9ee'),(31,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 03:08:00','2024-10-23 19:31:09',NULL,'2024-10-23 19:31:09',NULL,'5e42a05c-0f20-4abf-8532-3ba4659191d6'),(32,30,NULL,13,2,'craft\\elements\\Entry',1,0,'2024-10-23 03:16:30','2024-10-23 03:16:30',NULL,NULL,NULL,'6feefbec-8f81-46fa-b60a-2e2d5de6deb9'),(33,31,NULL,14,1,'craft\\elements\\Entry',1,0,'2024-10-23 03:16:30','2024-10-23 03:16:30',NULL,'2024-10-23 19:31:09',NULL,'51fd764e-94fc-4d3d-a75d-5ab60f8e9c89'),(35,18,NULL,15,3,'craft\\elements\\Entry',1,0,'2024-10-23 03:55:46','2024-10-23 03:55:46',NULL,NULL,NULL,'947b105d-a269-4a31-bb5c-a3432cd0deb3'),(36,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-23 18:45:54','2024-10-26 00:54:36',NULL,NULL,NULL,'68eb702b-d040-4945-b62a-d154d90dc0eb'),(37,36,NULL,16,3,'craft\\elements\\Entry',1,0,'2024-10-23 18:45:54','2024-10-23 18:45:54',NULL,NULL,NULL,'cc37e095-9568-4f7d-92ba-788fa9176d71'),(38,36,NULL,17,3,'craft\\elements\\Entry',1,0,'2024-10-23 18:46:37','2024-10-23 18:46:37',NULL,NULL,NULL,'a7a3ce5d-aff2-4499-aca8-74c8fe4cd636'),(40,36,NULL,18,3,'craft\\elements\\Entry',1,0,'2024-10-23 18:46:58','2024-10-23 18:46:58',NULL,NULL,NULL,'1438ae8d-6dca-4dee-9bd4-bf6815b33b02'),(44,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:06:27','2024-10-23 19:15:00',NULL,NULL,NULL,'569cb53d-7cbe-44f0-a4c8-3c9179a662ab'),(45,3,NULL,19,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:06:27','2024-10-23 19:06:27',NULL,NULL,NULL,'dd488713-b8bb-4dfd-ad94-a76085f8566a'),(46,44,NULL,20,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:06:27','2024-10-23 19:06:27',NULL,NULL,NULL,'50e23f22-56c7-4a4a-9a9d-eb5a7c079be2'),(48,3,NULL,21,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:06:38','2024-10-23 19:06:38',NULL,NULL,NULL,'83f07f27-5f30-496c-a6ca-2bf04fc84b86'),(58,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'90b797af-985e-4149-b6d1-847dd2515964'),(59,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'8551bf6c-24be-4907-b362-ee759b6cd0ba'),(60,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'cd5f5dee-451d-449f-a443-799d0f55a3c8'),(61,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'14a439fa-ca26-4b1c-bccf-8be58bd23487'),(62,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'20f5a1f6-9ad2-47ab-8b7b-bd69da8d5bc5'),(63,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'e11a871e-2102-4070-90dd-c51cbed2524b'),(64,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'c499380c-c7e4-4ccd-8903-920442dc4534'),(65,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:15:00',NULL,NULL,NULL,'d6367594-2197-49b1-a104-750c23ac7642'),(66,3,NULL,22,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'b060ffc6-8ff8-432f-959e-a4073f028109'),(67,44,NULL,23,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'08ee4889-d0fa-4087-8bd2-59c5c3c77827'),(68,58,NULL,24,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'61772ba6-f05f-4513-8134-4a421a6b2ac2'),(69,59,NULL,25,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'702e7e39-26f9-4841-b3d1-86350667bb8f'),(70,60,NULL,26,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'e0de62c0-8b39-4615-9a86-27c512b50a97'),(71,61,NULL,27,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'d0f9b653-611c-4ab0-bf3a-6e81b1002343'),(72,62,NULL,28,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'e3275c27-f281-4d2b-b451-e1dd628291df'),(73,63,NULL,29,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'3fbdcd64-d074-4443-be5d-24e2094aefc8'),(74,64,NULL,30,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'fb31dd7f-ee47-4817-81d8-b86f698c3e8c'),(75,65,NULL,31,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:12:36','2024-10-23 19:12:36',NULL,NULL,NULL,'6fb6d630-4c91-4dea-9d60-6721a030128b'),(78,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'899ff94c-ad8e-4f19-8fb0-2873d11ccb6e'),(79,3,NULL,32,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'d66feb5c-fc11-4df6-a0a2-6f30cd9a633d'),(80,44,NULL,33,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'ca40bfc6-50dd-48cf-9061-947b9f556ba1'),(81,58,NULL,34,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'805f4254-6094-42c5-b767-679a6be4f83c'),(82,59,NULL,35,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'c11958cd-d069-46c0-b3f9-b2d164397a7e'),(83,60,NULL,36,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'25536a82-5144-46ef-9442-4482b768d1f0'),(84,61,NULL,37,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'579d8153-2ad4-4744-b19e-7b322f48160d'),(85,62,NULL,38,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'4a7f917c-6330-4956-882d-e0a2c6614866'),(86,78,NULL,39,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'26af47bd-a31f-4e96-b051-a16d60f82157'),(87,63,NULL,40,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'560954c7-ec14-48db-9006-3e817020ff3d'),(88,64,NULL,41,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'bcdd3fa3-2ee7-4f3e-bc11-ebf014fd3551'),(89,65,NULL,42,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:15:00','2024-10-23 19:15:00',NULL,NULL,NULL,'a07af14f-2ea0-44ee-9527-6afe3366f2c7'),(91,22,NULL,43,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:25:32','2024-10-23 19:25:32',NULL,NULL,NULL,'56c0ccd9-a7dc-4cf0-bb7b-9394ca66b959'),(108,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'e85f4e8c-5d2f-476c-8b5b-332334a9944f'),(109,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'82e17032-ff0e-4bfc-9d70-4defa0e74456'),(110,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'3ab45437-1397-4002-855d-598bc6845e5c'),(111,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'3d2f4299-b82f-4e78-a591-e0b5c4a35852'),(112,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'f6bd3fb3-740a-4ccd-95d7-89a01afe6ead'),(113,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'8ad59a18-3e0a-4352-8d92-214b19fd06c9'),(114,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'b220a9af-2314-40cd-815f-0d3b2777c0b1'),(115,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'4be8e14c-6800-4b0f-9a93-41d8470d1fd1'),(116,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'f2928b06-b79c-4a8a-80db-e77445e62698'),(117,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'b40331a2-c826-4d88-9f22-4d465d6579df'),(118,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'8a833471-539f-4362-8e65-25c6a21a3806'),(119,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'d5cc0c7a-4ce4-4824-94a6-5f12c477c52d'),(120,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'43bcf59e-759b-4094-a0e0-89e9646e5f69'),(121,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'ed6b9f5a-7157-456a-b083-4d8c34c0ef4d'),(122,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'75be3055-0642-410d-ac96-cd9124ca7335'),(123,30,NULL,44,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'366e1610-3d19-4a7e-851c-4bf2577c58dd'),(124,108,NULL,45,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'02ef0956-4807-45a0-af8b-a5c9ff52600b'),(125,109,NULL,46,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'16883de8-d964-4b6b-9332-b635df8c1b24'),(126,110,NULL,47,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'3ca933e2-0ac1-4cbe-ae35-037d1ce9f1ff'),(127,111,NULL,48,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'280a4a41-171f-4381-9541-e2c67197fd07'),(128,112,NULL,49,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'d9aef65c-5665-4b48-a275-6db2887ddf3d'),(129,113,NULL,50,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'14e2df5f-a5fa-4d5d-900d-423b9ac2e5a5'),(130,114,NULL,51,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'207835fa-ea99-4b7b-9157-f3eeb212376f'),(131,115,NULL,52,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'5fdacd03-4aff-4734-b04f-f52ebec320de'),(132,116,NULL,53,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'47ec53d6-efda-40f7-8412-d7a6b6d1e4cf'),(133,117,NULL,54,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'91a21cfd-98c6-4ad7-97e4-985517e3bc70'),(134,118,NULL,55,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'a9e4b7d0-b3d1-4968-8ae1-81c3080407af'),(135,119,NULL,56,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'39728a4e-2a40-4aef-a6da-2a05d14f7ae4'),(136,120,NULL,57,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'4a381a1e-6007-4f65-b340-35d7ad2f1106'),(137,121,NULL,58,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'d8ec4bfa-4be2-4e46-904f-8ebf9ec412d9'),(138,122,NULL,59,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:31:09','2024-10-23 19:31:09',NULL,NULL,NULL,'aafe61f3-83a8-4a72-aa4c-778b7d8f04c3'),(148,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'ff7a35a9-a1f8-463c-b693-21b8fbe3ee58'),(149,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'f141a57b-df5d-4a1e-96be-744f3f59456c'),(150,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'530e7765-9b99-4cc8-a18a-38591fca3b61'),(151,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'e840fc35-c8b1-45ad-a214-73df9a4d236a'),(152,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'574f14b5-b171-4766-9d3f-939e94c25e14'),(153,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'9155e459-44c6-46f3-9d8d-ed55ee029f30'),(154,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'3adff9a7-d40e-494d-adca-89121f4f5e5f'),(155,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'eee5580c-a323-42cd-b9cc-b19c566fe1e1'),(156,22,NULL,60,2,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'21ab8951-7563-487c-8d63-59a02d963c21'),(157,148,NULL,61,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'3fbfbbc8-6ff4-4bd8-a7ec-e5cf27ae22ad'),(158,149,NULL,62,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'b46887da-6919-4923-8b70-d7e8752518dd'),(159,150,NULL,63,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'0aaa1ad4-ea69-4ecf-be7f-b7aef55ad028'),(160,151,NULL,64,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'0c8e7f92-82ee-4a43-91f7-9317877c8e64'),(161,152,NULL,65,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'d012a6c8-758b-4a16-8673-40cbb547ba6b'),(162,153,NULL,66,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'1b0e0057-8c67-4cf7-b1f8-f1b9c64dadf5'),(163,154,NULL,67,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'abbf34eb-7256-47b9-bf43-5fea2da7a019'),(164,155,NULL,68,1,'craft\\elements\\Entry',1,0,'2024-10-23 19:35:25','2024-10-23 19:35:25',NULL,NULL,NULL,'73db0613-8804-4121-9e00-7ecf7431465e'),(166,30,NULL,69,2,'craft\\elements\\Entry',1,0,'2024-10-25 17:17:57','2024-10-25 17:17:57',NULL,NULL,NULL,'9bcfe1b6-1385-414b-a266-f0984daf759d'),(167,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-25 17:18:37','2024-10-25 17:19:51',NULL,NULL,NULL,'66e095e2-1222-4178-8acb-6f6e71df61e8'),(168,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:18:46','2024-10-25 17:19:51',NULL,NULL,NULL,'011da795-b7e5-41c6-8a0e-70c85d980876'),(169,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:19:07','2024-10-25 17:19:51',NULL,NULL,NULL,'37ee6abd-ad90-4908-b945-61067ce249de'),(170,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:19:28','2024-10-25 17:19:51',NULL,NULL,NULL,'6468dd31-4714-42e6-a7d1-58a51be4a31d'),(171,167,NULL,70,2,'craft\\elements\\Entry',1,0,'2024-10-25 17:19:51','2024-10-25 17:19:51',NULL,NULL,NULL,'8e479235-ef1b-4743-804a-4ebc020cac7c'),(172,168,NULL,71,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:19:51','2024-10-25 17:19:51',NULL,NULL,NULL,'b491f8c2-780a-4b1c-b570-94b33071f758'),(173,169,NULL,72,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:19:51','2024-10-25 17:19:51',NULL,NULL,NULL,'cc1880f0-e6f2-4a38-984a-c6a80615739f'),(174,170,NULL,73,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:19:51','2024-10-25 17:19:51',NULL,NULL,NULL,'20d435fd-7f3a-4114-acf5-2fced0a59435'),(175,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-25 17:20:35','2024-10-25 17:23:49',NULL,NULL,NULL,'5b506ddd-4be1-4e35-8939-b09cc318f5de'),(176,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:20:46','2024-10-25 17:23:49',NULL,NULL,NULL,'46aeccea-fa9c-46b3-bdf5-1ec8fd486e6c'),(177,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:21:17','2024-10-25 17:23:49',NULL,NULL,NULL,'588c7c40-b7d5-4e81-877a-53c620be0e98'),(178,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:21:45','2024-10-25 17:23:49',NULL,NULL,NULL,'7b73a9bc-ba7d-48c9-91d2-176cd6ff0ba5'),(179,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:22:26','2024-10-25 17:23:49',NULL,NULL,NULL,'bb3bfb64-78bc-473a-a56b-18cbd34d4af1'),(180,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:22:43','2024-10-25 17:23:49',NULL,NULL,NULL,'d4142280-5cd7-45d2-b188-62d4d2805a31'),(181,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:20','2024-10-25 17:23:49',NULL,NULL,NULL,'d2dc4378-1def-47d3-a42d-07f62aef9d5a'),(182,175,NULL,74,2,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'271336d3-8b0b-4845-83d9-771baf974118'),(183,176,NULL,75,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'9c426e4e-9481-40b6-9660-0f1ffb7fac8e'),(184,177,NULL,76,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'4b0ffc25-c990-478d-b975-5cff58f5ba1c'),(185,178,NULL,77,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'2fc76c7e-96c8-4e4e-bcf1-57d3915fc105'),(186,179,NULL,78,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'cd3dddac-b32a-460b-b4ea-0735f034971e'),(187,180,NULL,79,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'e4bbaf15-2660-4d5a-8be0-861887ad722a'),(188,181,NULL,80,1,'craft\\elements\\Entry',1,0,'2024-10-25 17:23:49','2024-10-25 17:23:49',NULL,NULL,NULL,'7cfce6d1-8471-4179-be48-416627a57c47'),(189,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-25 19:53:58','2024-10-25 23:19:52',NULL,NULL,NULL,'845ac9b2-e61f-4f5a-9975-f0e6dfe61acb'),(190,189,NULL,81,3,'craft\\elements\\Entry',1,0,'2024-10-25 19:53:58','2024-10-25 19:53:58',NULL,NULL,NULL,'a70b7673-37a7-4977-9f8f-1f90d055691c'),(192,36,NULL,82,3,'craft\\elements\\Entry',1,0,'2024-10-25 23:18:34','2024-10-25 23:18:34',NULL,NULL,NULL,'12e74cc2-512f-47a0-b451-702e75841cf7'),(194,36,NULL,83,3,'craft\\elements\\Entry',1,0,'2024-10-25 23:18:53','2024-10-25 23:18:53',NULL,NULL,NULL,'babbb74f-c7bf-4212-bccb-56cd32000635'),(196,189,NULL,84,3,'craft\\elements\\Entry',1,0,'2024-10-25 23:19:52','2024-10-25 23:19:52',NULL,NULL,NULL,'4a275855-be02-4803-a0cd-bf9658f0e1f8'),(198,18,NULL,85,3,'craft\\elements\\Entry',1,0,'2024-10-25 23:21:06','2024-10-25 23:21:06',NULL,NULL,NULL,'ad6cd667-b79d-4b46-90a7-cfc76442a6ae'),(199,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:12:14','2024-10-26 00:13:42',NULL,NULL,NULL,'828094a3-002d-4773-91ce-69d517ed140f'),(200,199,NULL,86,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:12:14','2024-10-26 00:12:14',NULL,NULL,NULL,'7af45f47-d00f-4b8b-ab71-3c880ebabb07'),(202,199,NULL,87,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:13:29','2024-10-26 00:13:29',NULL,NULL,NULL,'4a9dfc05-e866-4243-86ab-f80deff8396a'),(204,199,NULL,88,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:13:42','2024-10-26 00:13:42',NULL,NULL,NULL,'70f745da-d879-4970-8bef-4626152e1495'),(206,36,NULL,89,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:50:46','2024-10-26 00:50:46',NULL,NULL,NULL,'c340293f-853a-4426-82ae-e8c8593d480a'),(208,36,NULL,90,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:51:20','2024-10-26 00:51:20',NULL,NULL,NULL,'c590d71d-6ca2-4aa5-a168-7db282c50503'),(210,36,NULL,91,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:52:04','2024-10-26 00:52:04',NULL,NULL,NULL,'57475163-e6e4-4394-a36d-eef982f382b3'),(212,36,NULL,92,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:52:41','2024-10-26 00:52:41',NULL,NULL,NULL,'4b1aa544-ba6e-436f-9a19-48e2cdec8bf3'),(214,36,NULL,93,3,'craft\\elements\\Entry',1,0,'2024-10-26 00:54:36','2024-10-26 00:54:36',NULL,NULL,NULL,'6ed6f3f8-0db4-4046-8cbb-65eccd8f83d7');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES (8,3,1),(10,9,1),(14,3,2),(16,15,1),(17,15,2),(23,22,1),(24,22,2),(26,25,1),(27,25,2),(31,30,1),(33,32,1),(44,3,1),(46,45,1),(46,48,1),(58,3,2),(59,3,3),(60,3,4),(61,3,5),(62,3,6),(63,3,8),(64,3,9),(65,3,10),(67,66,1),(68,66,2),(69,66,3),(70,66,4),(71,66,5),(72,66,6),(73,66,7),(74,66,8),(75,66,9),(78,3,7),(80,79,1),(81,79,2),(82,79,3),(83,79,4),(84,79,5),(85,79,6),(86,79,7),(87,79,8),(88,79,9),(89,79,10),(108,30,1),(109,30,2),(110,30,3),(111,30,4),(112,30,5),(113,30,6),(114,30,7),(115,30,8),(116,30,9),(117,30,10),(118,30,11),(119,30,12),(120,30,13),(121,30,14),(122,30,15),(124,123,1),(124,166,1),(125,123,2),(125,166,2),(126,123,3),(126,166,3),(127,123,4),(127,166,4),(128,123,5),(128,166,5),(129,123,6),(129,166,6),(130,123,7),(130,166,7),(131,123,8),(131,166,8),(132,123,9),(132,166,9),(133,123,10),(133,166,10),(134,123,11),(134,166,11),(135,123,12),(135,166,12),(136,123,13),(136,166,13),(137,123,14),(137,166,14),(138,123,15),(138,166,15),(148,22,1),(149,22,2),(150,22,3),(151,22,4),(152,22,5),(153,22,6),(154,22,7),(155,22,8),(157,156,1),(158,156,2),(159,156,3),(160,156,4),(161,156,5),(162,156,6),(163,156,7),(164,156,8),(168,167,1),(169,167,2),(170,167,3),(172,171,1),(173,171,2),(174,171,3),(176,175,1),(177,175,2),(178,175,3),(179,175,4),(180,175,5),(181,175,6),(183,182,1),(184,182,2),(185,182,3),(186,182,4),(187,182,5),(188,182,6);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-10-22 23:54:39','2024-10-22 23:54:39','c96f57f5-53aa-4e35-b152-df060b4d60a6'),(2,2,1,NULL,'__temp_dboqyllwacewdrtlczbiyaivadxqlntecaly','menu/__temp_dboqyllwacewdrtlczbiyaivadxqlntecaly',NULL,1,'2024-10-23 02:10:16','2024-10-23 02:10:16','e0dfa89a-980f-41cf-acd2-3beef7113fc4'),(3,3,1,'Specialty','specialty','menu/specialty',NULL,1,'2024-10-23 02:10:16','2024-10-23 19:06:38','78c0d03f-0493-4fb3-ba4c-ae8263a24856'),(5,5,1,'Appetizers','appetizers','menu/appetizers',NULL,1,'2024-10-23 02:10:37','2024-10-23 02:10:37','8b5eb52e-d123-483b-a0bf-e1b9f3e011c0'),(8,8,1,'Mozz Sticks','mozz-sticks',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 02:11:12','2024-10-23 02:11:56','d872a5e6-7468-4792-9635-b1db6b674290'),(9,9,1,'Appetizers','appetizers','menu/appetizers',NULL,1,'2024-10-23 02:11:12','2024-10-23 02:11:12','a5bbfd70-228e-4ac1-bf08-f6ca0387f56e'),(10,10,1,'Mozz Sticks','mozz-sticks',NULL,NULL,1,'2024-10-23 02:11:12','2024-10-23 02:11:12','163e4e63-15e6-4911-9ae3-049ee96bb39a'),(14,14,1,'French Fries','french-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"599\"}',1,'2024-10-23 02:12:23','2024-10-23 02:12:23','4e98c73e-af49-4335-823d-6790447bfdf9'),(15,15,1,'Appetizers','appetizers','menu/appetizers',NULL,1,'2024-10-23 02:12:23','2024-10-23 02:12:23','5aaeb046-8700-4149-a4ac-cd684a024182'),(16,16,1,'Mozz Sticks','mozz-sticks',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 02:12:23','2024-10-23 02:12:23','27eac492-95bb-4b82-82fd-daeab7476f10'),(17,17,1,'French Fries','french-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"599\"}',1,'2024-10-23 02:12:23','2024-10-23 02:12:23','0972ba73-e174-4260-900f-70e950a268d5'),(18,18,1,'Our Menu','menu-index','menu','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Order Now!</h4>\"}',1,'2024-10-23 02:30:22','2024-10-25 23:21:06','655aedb3-7c83-4f42-a15b-c6a681b920f7'),(19,19,1,'Menu Index','menu-index','menu',NULL,1,'2024-10-23 02:30:22','2024-10-23 02:30:22','837fd77e-40e8-4ca7-a364-ac21ff2654d5'),(21,21,1,'Menu Index','menu-index','menu','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>Some regular old text.</p><p>Maybe with a heading?</p><h2>A Heading</h2>\"}',1,'2024-10-23 02:31:10','2024-10-23 02:31:10','458bf0d6-9f45-46f2-9e83-e9645cb24e5f'),(22,22,1,'Subs','subs','menu/subs',NULL,1,'2024-10-23 03:00:20','2024-10-23 19:25:32','deb05200-e06e-4885-b528-8093f59aba9d'),(23,23,1,'Turkey','turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"988\"}',1,'2024-10-23 03:00:53','2024-10-23 03:01:05','cdd1a1d9-aa9a-4192-b37b-4d08c24e8909'),(24,24,1,'Roast Beef','roast-beef',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1299\"}',1,'2024-10-23 03:01:09','2024-10-23 03:01:21','cf0e9a8b-4836-4f5d-b4a1-7130796e4602'),(25,25,1,'Deli Sandwiches','deli-sandwiches','menu/deli-sandwiches',NULL,1,'2024-10-23 03:01:27','2024-10-23 03:01:27','939abe34-f579-4604-8ea9-601f1861f9bc'),(26,26,1,'Turkey','turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"988\"}',1,'2024-10-23 03:01:27','2024-10-23 03:01:27','b9496874-9c75-4fac-8dfd-7597819f167b'),(27,27,1,'Roast Beef','roast-beef',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1299\"}',1,'2024-10-23 03:01:27','2024-10-23 03:01:27','66a8b132-12bd-40dc-abca-2e6254708b7d'),(29,29,1,'Menu Index','menu-index','menu',NULL,1,'2024-10-23 03:02:37','2024-10-23 03:02:37','14a1bfc7-9435-47fd-9ee9-06790a568fad'),(30,30,1,'Deli Meat & Cheese','hot-sandwiches','menu/hot-sandwiches',NULL,1,'2024-10-23 03:07:49','2024-10-25 17:17:57','e9f068ae-dd78-42e6-900c-21c851a182a9'),(31,31,1,'Octopus','octopus',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1399\"}',1,'2024-10-23 03:08:00','2024-10-23 03:08:13','c90d2a04-2ba8-4b3f-adae-5a624f9a08dc'),(32,32,1,'Hot Sandwiches','hot-sandwiches','menu/hot-sandwiches',NULL,1,'2024-10-23 03:16:30','2024-10-23 03:16:30','9767386a-0af2-4230-a775-9ef88ca463fe'),(33,33,1,'Octopus','octopus',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1399\"}',1,'2024-10-23 03:16:30','2024-10-23 03:16:30','2eef6461-ccd0-4c7f-99cc-f93c15f2cff7'),(35,35,1,'Our Menu','menu-index','menu',NULL,1,'2024-10-23 03:55:46','2024-10-23 03:55:46','a4cf0589-4753-42f0-9995-4ac043853ec2'),(36,36,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>We\'re always happy to hear from you.</p><p> </p>\"}',1,'2024-10-23 18:45:54','2024-10-26 00:54:36','8ee7883c-b7f7-4278-aff7-3c6b4581b746'),(37,37,1,'Contact','contact','contact',NULL,1,'2024-10-23 18:45:54','2024-10-23 18:45:54','48e65f09-431b-49eb-b240-4b1c9e09ff58'),(38,38,1,'Contact','contact','contact',NULL,1,'2024-10-23 18:46:37','2024-10-23 18:46:37','fdfe3d75-9477-45d8-89b2-5c80368cc2ac'),(40,40,1,'Contact','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>Contact info to follow.</p>\"}',1,'2024-10-23 18:46:58','2024-10-23 18:46:58','916ecc01-f716-41df-97b1-eb79147dc83d'),(44,44,1,'Chicken over Rice','chicken-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:06:27','2024-10-23 19:06:27','43c236d5-2cdc-44c9-98db-d533b9028e1e'),(45,45,1,'Specialty','appetizers','menu/appetizers',NULL,1,'2024-10-23 19:06:27','2024-10-23 19:06:27','be6ac1f9-619f-4184-b157-5a01013e604b'),(46,46,1,'Chicken over Rice','chicken-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:06:27','2024-10-23 19:06:27','3d3643b4-442a-4bcd-8cf1-501fefa981ec'),(48,48,1,'Specialty','specialty','menu/specialty',NULL,1,'2024-10-23 19:06:38','2024-10-23 19:06:38','07c0696f-14c8-482a-a5f4-599eda573311'),(58,58,1,'Lamb over Rice','lamb-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','16510b10-e9c1-4be1-ad15-b7a6b88f70f9'),(59,59,1,'Chicken & Lamb','chicken-lamb',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1299\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','e7a82d00-bae9-46bd-a43d-47be87990c3c'),(60,60,1,'Steak over Rice','steak-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"899\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','aa1aec83-ca93-491c-ae4c-a85d67bc77fb'),(61,61,1,'Fish over Rice','fish-over-rice',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1199\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','70a7440a-be94-4482-8f1a-7d3963be6f59'),(62,62,1,'Six Pieces Shrimp over Rice','six-pieces-shrimp-over-rice',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1499\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','a65db5ea-1f16-439e-bf72-b5ac59a7b57f'),(63,63,1,'Cheesburger w/Fries','cheesburger-w-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','36c266d0-aae5-4c74-b75b-b472a6707aa9'),(64,64,1,'Double Cheesburger w/Fries','double-cheesburger-w-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"849\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','186ede5a-bc6e-4044-ba17-fd8020bb6da0'),(65,65,1,'Cheese Sticks (3)','cheese-sticks-3',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"299\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','653279ed-42ab-474c-a984-0b3ccffc2cd4'),(66,66,1,'Specialty','specialty','menu/specialty',NULL,1,'2024-10-23 19:12:36','2024-10-23 19:12:36','12c258e6-49b5-49d5-9874-6229a61d903b'),(67,67,1,'Chicken over Rice','chicken-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','6ac75f87-34bd-45a5-adc8-1c8fd8c7c7cc'),(68,68,1,'Lamb over Rice','lamb-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','44798206-71db-466d-a844-434a0b317bb8'),(69,69,1,'Chicken & Lamb','chicken-lamb',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1299\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','8ad88401-a1cb-4a5f-b0ea-d3811eec0ca5'),(70,70,1,'Steak over Rice','steak-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"899\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','13e70c49-69f5-4e94-aa93-04c361e2ea2f'),(71,71,1,'Fish over Rice','fish-over-rice',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1199\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','473cc93c-a9cc-4071-8710-39dd05e7d7bf'),(72,72,1,'Six Pieces Shrimp over Rice','six-pieces-shrimp-over-rice',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1499\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','ee10e4c4-05f0-4a62-b78d-ceff2e043678'),(73,73,1,'Cheesburger w/Fries','cheesburger-w-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','b72e92f2-2cf6-4d7a-8fd5-44f81046d3c9'),(74,74,1,'Double Cheesburger w/Fries','double-cheesburger-w-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"849\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','8098329d-ad7c-42fb-a672-44accd18eb1e'),(75,75,1,'Cheese Sticks (3)','cheese-sticks-3',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"299\"}',1,'2024-10-23 19:12:36','2024-10-23 19:12:36','fe3f1f70-12cd-4f7f-8333-b9c7b004a4a1'),(78,78,1,'Fish & Shrimp over Rice','fish-shrimp-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1499\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1099\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','fbb9af18-6914-416b-8950-13ec8173af05'),(79,79,1,'Specialty','specialty','menu/specialty',NULL,1,'2024-10-23 19:15:00','2024-10-23 19:15:00','5cea0060-3251-4292-be52-236da2d35de9'),(80,80,1,'Chicken over Rice','chicken-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','c0bee3cd-ce71-4a37-8c4b-3bc23dc76edc'),(81,81,1,'Lamb over Rice','lamb-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','af3ccb63-1fa1-4d70-8b51-ccc9e029f74a'),(82,82,1,'Chicken & Lamb','chicken-lamb',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1299\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','40e5380f-4dd0-471b-879e-a675f111c79b'),(83,83,1,'Steak over Rice','steak-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"899\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','e6db8838-927a-48e2-b73a-27aad30a3ca1'),(84,84,1,'Fish over Rice','fish-over-rice',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1199\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','f902904e-74c6-4a2d-b4f9-e427b43fe6a6'),(85,85,1,'Six Pieces Shrimp over Rice','six-pieces-shrimp-over-rice',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1499\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','e7ebbf7b-39fa-4bae-9d70-a7e819290b5a'),(86,86,1,'Fish & Shrimp over Rice','fish-shrimp-over-rice',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1499\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1099\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','77c730dc-403c-4b50-85dd-32a0bd8164f1'),(87,87,1,'Cheesburger w/Fries','cheesburger-w-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','0a148589-1b5e-46dd-a8e7-c18b25f012f0'),(88,88,1,'Double Cheesburger w/Fries','double-cheesburger-w-fries',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"849\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','29001f9e-b497-4f89-9361-ec1a5b0cedd8'),(89,89,1,'Cheese Sticks (3)','cheese-sticks-3',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"299\"}',1,'2024-10-23 19:15:00','2024-10-23 19:15:00','9842e844-2542-46bb-8d3c-e88d6cc52256'),(91,91,1,'Subs','subs','menu/subs',NULL,1,'2024-10-23 19:25:32','2024-10-23 19:25:32','e88764c4-5418-42bb-bcd8-7a67ed84b30a'),(108,108,1,'Turkey','turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','68cbd55f-0df5-4f10-9984-248ad7b6f39a'),(109,109,1,'Honey Turkey','honey-turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','88a322b1-95e7-41a3-849e-4b6d1c29fbb8'),(110,110,1,'Cajun Turkey','cajun-turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','6c687570-bc94-41a8-ba3b-104cc4dbe0bc'),(111,111,1,'Turkey Pastrami','turkey-pastrami',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','505e8d1f-8c75-483b-b538-4bea0a9a73a9'),(112,112,1,'Roast Beef','roast-beef',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','14e6eaa3-2c2a-40b9-a98d-882ff96b1ed5'),(113,113,1,'Beef Salami','beef-salami',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','b6fa20b8-2fb8-4065-819e-ee2bdede1c41'),(114,114,1,'Beef Pastrami','beef-pastrami',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','10d86c85-256b-4280-997f-b7a4c2b9f90d'),(115,115,1,'Beef Bolgna','beef-bolgna',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','ccecc2ba-5ac7-43ff-949b-00a942ab0cf0'),(116,116,1,'Buffalo Chicken','buffalo-chicken',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','12789348-b53c-4671-b10e-07a0e7bde3cc'),(117,117,1,'BBQ Chicken','bbq-chicken',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','347ef9a9-45a0-43d9-b9b0-2ad02472453f'),(118,118,1,'Cheese','cheese',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','b344e77a-7558-439c-8d8a-65665c7ea094'),(119,119,1,'American','american',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"899\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','39da8a59-9b4b-47f6-b6db-a2e6e931a9f7'),(120,120,1,'Provolone','provolone',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','2f1e3de1-9cdc-43a9-86fd-eb4a60adcdce'),(121,121,1,'Swiss','swiss',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','790d6bb9-c8b5-4561-9718-3cbba45ca55c'),(122,122,1,'Pepper Jack','pepper-jack',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','73369f52-b128-4bae-9cfb-f7562a1095d3'),(123,123,1,'Deli Meats and Cheese','hot-sandwiches','menu/hot-sandwiches',NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','712c851d-886e-4936-8959-fd63014304ca'),(124,124,1,'Turkey','turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','d3833cfd-300f-4a04-b574-5595dec59b34'),(125,125,1,'Honey Turkey','honey-turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','bf21b950-302d-4165-83f9-383858219d4f'),(126,126,1,'Cajun Turkey','cajun-turkey',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','f7be7cf6-99bb-4f20-8bf5-42b9893fef66'),(127,127,1,'Turkey Pastrami','turkey-pastrami',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','17174fc4-2d75-422e-a10c-2c27b8609a0e'),(128,128,1,'Roast Beef','roast-beef',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','7d238b5a-0891-4c33-a682-ec6e7ecafd54'),(129,129,1,'Beef Salami','beef-salami',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','ddb9c5c3-b1f7-4e9d-8eb3-2f8e33154b85'),(130,130,1,'Beef Pastrami','beef-pastrami',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','fa68e30e-ab80-4585-a6aa-c94a0542c734'),(131,131,1,'Beef Bolgna','beef-bolgna',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','c7a7fde3-b905-49aa-a7e6-0d7ccd7e8981'),(132,132,1,'Buffalo Chicken','buffalo-chicken',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','5661084d-e5d5-4227-a63b-54d7f70a2067'),(133,133,1,'BBQ Chicken','bbq-chicken',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','086ddf74-cc9c-4d84-9ed7-f0dcc74acce2'),(134,134,1,'Cheese','cheese',NULL,NULL,1,'2024-10-23 19:31:09','2024-10-23 19:31:09','634f8dce-094e-4205-8cc9-663bbc45ec6c'),(135,135,1,'American','american',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"899\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','4c20e09f-c966-43e0-84d2-ee4bf545da25'),(136,136,1,'Provolone','provolone',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','a8e02336-a5da-4e40-b364-efdb0d0b22d4'),(137,137,1,'Swiss','swiss',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','86770db0-29ca-44a4-b450-2d051153d4b1'),(138,138,1,'Pepper Jack','pepper-jack',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-23 19:31:09','2024-10-23 19:31:09','874df25b-4ad7-41a1-8ea0-e15926e091b7'),(148,148,1,'Roll','roll',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','c7fce872-d5cb-4c28-bc55-143813588ddf'),(149,149,1,'Small Sub','small-sub',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','3bd13534-585c-4f01-8fde-af75916037de'),(150,150,1,'Large Sub','large-sub',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1099\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','4a162f43-5c2f-4f35-adca-d6cbfb12ec1b'),(151,151,1,'Add Any Meat','add-any-meat',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"100\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','6bce87a0-9120-48e4-8f26-f7e8d05ca572'),(152,152,1,'Add Any Topping','add-any-topping',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"50\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','5dc7a23f-6939-40d3-a97b-26563f1eda8c'),(153,153,1,'Buffalo Chicken Sub','buffalo-chicken-sub',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','bd629c24-9c40-4920-81f8-d26fcd443d1b'),(154,154,1,'Chooped Cheese Roll','chooped-cheese-roll',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','d671112a-1406-46c7-abfe-27f7444e5b92'),(155,155,1,'Philly Cheese Steak','philly-cheese-steak',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','e3610761-1e13-4886-b88e-bacf2d6e2ce3'),(156,156,1,'Subs','subs','menu/subs',NULL,1,'2024-10-23 19:35:25','2024-10-23 19:35:25','d26b7c5d-db0c-43e0-9243-b911599219be'),(157,157,1,'Roll','roll',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','3d5f1e57-1e07-423b-a25d-77f0ad4daefe'),(158,158,1,'Small Sub','small-sub',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','f5fa23e7-274e-4662-943c-fba59232be8e'),(159,159,1,'Large Sub','large-sub',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"1099\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','a194849a-f6eb-4203-b9cf-1cc894c086ac'),(160,160,1,'Add Any Meat','add-any-meat',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"100\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','d5fa5c13-b92d-4d60-a7b5-4913492b2827'),(161,161,1,'Add Any Topping','add-any-topping',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"50\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','3e3d5c51-514d-4512-bbc8-cbec6bd6206d'),(162,162,1,'Buffalo Chicken Sub','buffalo-chicken-sub',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','0cb9bb0e-09ab-4f05-9a3b-285d451f3d32'),(163,163,1,'Chooped Cheese Roll','chooped-cheese-roll',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','d602d434-4e33-45b1-8e49-fc9cc399c412'),(164,164,1,'Philly Cheese Steak','philly-cheese-steak',NULL,'{\"524df69c-fc97-4519-bde4-02426cc2155a\": \"1099\", \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"799\"}',1,'2024-10-23 19:35:25','2024-10-23 19:35:25','6024a8b9-e54f-4609-a8bf-f9dec9c4b8ff'),(166,166,1,'Deli Meat & Cheese','hot-sandwiches','menu/hot-sandwiches',NULL,1,'2024-10-25 17:17:57','2024-10-25 17:17:57','2fbfea09-8888-41ba-a2b5-b075e6cdcd9c'),(167,167,1,'Gyros','gyros','menu/gyros',NULL,1,'2024-10-25 17:18:37','2024-10-25 17:18:42','c58a6f82-3f65-4add-8a7d-ee1c975b0a6f'),(168,168,1,'Chicken Gyro','chicken-gyro',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-25 17:18:46','2024-10-25 17:19:03','acd1e9b5-3f71-486d-abc1-3a0d9082cf38'),(169,169,1,'Lamb Gyro','lamb-gyro',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-25 17:19:07','2024-10-25 17:19:25','21029329-ed0b-44af-af7c-49b9c684d8e8'),(170,170,1,'Chicken & Lamb Gyro','chicken-lamb-gyro',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-25 17:19:28','2024-10-25 17:19:46','2f8920c3-4a6f-48b4-af2a-8b19375cc368'),(171,171,1,'Gyros','gyros','menu/gyros',NULL,1,'2024-10-25 17:19:51','2024-10-25 17:19:51','fe654159-7710-4816-b42a-1e04cb8112da'),(172,172,1,'Chicken Gyro','chicken-gyro',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-25 17:19:51','2024-10-25 17:19:51','caa375f2-63ac-4c99-9294-b8703a10b691'),(173,173,1,'Lamb Gyro','lamb-gyro',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-25 17:19:51','2024-10-25 17:19:51','63c256b7-f03c-42c8-9922-32584e026b8b'),(174,174,1,'Chicken & Lamb Gyro','chicken-lamb-gyro',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"999\"}',1,'2024-10-25 17:19:51','2024-10-25 17:19:51','e445c8e4-9602-4108-bd80-5cceedac8ae8'),(175,175,1,'Breakfast','breakfast','menu/breakfast',NULL,1,'2024-10-25 17:20:35','2024-10-25 17:24:04','99b058aa-760f-46a5-a943-681bdd9e7253'),(176,176,1,'Turkey Bacon, Egg & Cheese','turkey-bacon-egg-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"599\"}',1,'2024-10-25 17:20:46','2024-10-25 17:21:09','c1c79583-5ef2-4746-8ab3-505ddfb0ea49'),(177,177,1,'Sausage, Egg & Cheese','sausage-egg-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-25 17:21:17','2024-10-25 17:21:37','998691bb-ac39-44c4-a28f-bd97c675b33e'),(178,178,1,'Meat (your choice), Egg & Cheese','meat-your-choice-egg-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"599\"}',1,'2024-10-25 17:21:45','2024-10-25 17:22:18','07cad7ef-2754-41ea-a146-7af31cb8150f'),(179,179,1,'Buttered Roll','buttered-roll',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"250\"}',1,'2024-10-25 17:22:26','2024-10-25 17:22:39','93339333-f46c-4272-b02e-7796fa89a953'),(180,180,1,'Roll or Bagel w/Cream Cheese','roll-or-bagel-w-cream-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"350\"}',1,'2024-10-25 17:22:43','2024-10-25 17:23:11','03d95ff5-171a-4502-990e-55f01ef33907'),(181,181,1,'Roll or Bagel w/Ceam Cheese & Jam','roll-or-bagel-w-ceam-cheese-jam',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"399\"}',1,'2024-10-25 17:23:20','2024-10-25 17:23:45','c1289f22-6a9d-4571-a662-383d781108a3'),(182,182,1,'Breakfast','breakfast','menu/breakfast',NULL,1,'2024-10-25 17:23:49','2024-10-25 17:23:49','0c3507d4-b400-4ba9-8345-805377346aaf'),(183,183,1,'Turkey Bacon, Egg & Cheese','turkey-bacon-egg-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"599\"}',1,'2024-10-25 17:23:49','2024-10-25 17:23:49','f01ead0c-4a83-4c59-b05d-329caa23b574'),(184,184,1,'Sausage, Egg & Cheese','sausage-egg-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"699\"}',1,'2024-10-25 17:23:49','2024-10-25 17:23:49','62d6ade3-8579-4cf9-8447-3b1df97b72aa'),(185,185,1,'Meat (your choice), Egg & Cheese','meat-your-choice-egg-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"599\"}',1,'2024-10-25 17:23:49','2024-10-25 17:23:49','9cbb11c1-1608-4914-8a1e-c0e881c4582d'),(186,186,1,'Buttered Roll','buttered-roll',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"250\"}',1,'2024-10-25 17:23:49','2024-10-25 17:23:49','9189cd6c-d7f8-4aaa-8302-f70db093803d'),(187,187,1,'Roll or Bagel w/Cream Cheese','roll-or-bagel-w-cream-cheese',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"350\"}',1,'2024-10-25 17:23:49','2024-10-25 17:23:49','1fddb389-0b43-4ef0-80d6-f430745946a0'),(188,188,1,'Roll or Bagel w/Ceam Cheese & Jam','roll-or-bagel-w-ceam-cheese-jam',NULL,'{\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\": \"399\"}',1,'2024-10-25 17:23:49','2024-10-25 17:23:49','acba64e5-2853-4c4d-bc1b-cad81d013ea9'),(189,189,1,'About Us','about','about','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Why We\'re Different</h4>\"}',1,'2024-10-25 19:53:58','2024-10-25 23:19:52','cbbf824f-cdf7-49d5-9722-ce2694bb0259'),(190,190,1,'About','about','about',NULL,1,'2024-10-25 19:53:58','2024-10-25 19:53:58','09d0469d-af3b-4bb6-8ee3-c5c287de6ec8'),(192,192,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h3>Contact info to follow.</h3>\"}',1,'2024-10-25 23:18:34','2024-10-25 23:18:34','a5b37c1c-93eb-4a6e-ba2c-1b5648baa8ba'),(194,194,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Contact info to follow.</h4>\"}',1,'2024-10-25 23:18:53','2024-10-25 23:18:53','219f9823-702d-4683-a2cb-67194729b2fe'),(196,196,1,'About Us','about','about','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Why We\'re Different</h4>\"}',1,'2024-10-25 23:19:52','2024-10-25 23:19:52','29865887-da19-438b-9677-e7d6680f766c'),(198,198,1,'Our Menu','menu-index','menu','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Order Now!</h4>\"}',1,'2024-10-25 23:21:06','2024-10-25 23:21:06','024fc7a0-1322-4d6a-bf0f-6855d65c6589'),(199,199,1,'Subs, Gyros & More','home-page','__home__','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Order Now for Fast Delivery!</h4>\"}',1,'2024-10-26 00:12:14','2024-10-26 00:13:42','51ea263a-3b62-4a9c-826c-60578c3b941e'),(200,200,1,'Home Page','home-page','__home__',NULL,1,'2024-10-26 00:12:14','2024-10-26 00:12:14','c5a411cc-ef5d-47bf-82bc-31af9d4b85fc'),(202,202,1,'Subs, Gyros & More','home-page','__home__','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>Order Now for Fast Delivery!</p>\"}',1,'2024-10-26 00:13:29','2024-10-26 00:13:29','8c8efb9c-56ae-4445-ba7f-5a4a62c97cb5'),(204,204,1,'Subs, Gyros & More','home-page','__home__','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>Order Now for Fast Delivery!</h4>\"}',1,'2024-10-26 00:13:42','2024-10-26 00:13:42','f5a05a01-ce09-47a3-811c-49abf0a127ec'),(206,206,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>We\'re always happy to hear from you.</p><p><strong>[ADD email, social media, telephone, whatever.]</strong></p>\"}',1,'2024-10-26 00:50:46','2024-10-26 00:50:46','c4bde353-c85a-47a3-885e-191d6cad0d11'),(208,208,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>We\'re always happy to hear from you.</p><p>[ADD email, social media, telephone, whatever.]</p>\"}',1,'2024-10-26 00:51:20','2024-10-26 00:51:20','208d8052-1f91-4b45-a19f-03fdbebc7e2c'),(210,210,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<h4>We\'re always happy to hear from you.</h4><h4>[ADD email, social media, telephone, whatever.]</h4>\"}',1,'2024-10-26 00:52:04','2024-10-26 00:52:04','d2dc4380-543e-4b6a-adec-fc2f89c1765f'),(212,212,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>We\'re always happy to hear from you.</p><h4>[ADD email, social media, telephone, whatever.]</h4>\"}',1,'2024-10-26 00:52:41','2024-10-26 00:52:41','7720cd2f-6f1c-476a-9d11-aa99be9d1dce'),(214,214,1,'Contact Us','contact','contact','{\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\": \"<p>We\'re always happy to hear from you.</p><p> </p>\"}',1,'2024-10-26 00:54:36','2024-10-26 00:54:36','66a01301-b0a5-4a77-9703-f1d47f54b89b');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,2,'2024-10-23 02:10:16',NULL,NULL,'2024-10-23 02:10:16','2024-10-23 02:10:16'),(3,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 02:10:16','2024-10-23 02:10:37'),(5,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 02:10:37','2024-10-23 02:10:37'),(8,NULL,NULL,3,2,1,'2024-10-23 02:11:00',NULL,0,'2024-10-23 02:11:12','2024-10-23 02:11:12'),(9,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 02:11:12','2024-10-23 02:11:12'),(10,NULL,NULL,9,2,1,'2024-10-23 02:11:00',NULL,NULL,'2024-10-23 02:11:12','2024-10-23 02:11:12'),(14,NULL,NULL,3,2,1,'2024-10-23 02:12:00',NULL,0,'2024-10-23 02:12:23','2024-10-23 02:12:23'),(15,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 02:12:23','2024-10-23 02:12:23'),(16,NULL,NULL,15,2,1,'2024-10-23 02:11:00',NULL,NULL,'2024-10-23 02:12:23','2024-10-23 02:12:23'),(17,NULL,NULL,15,2,1,'2024-10-23 02:12:00',NULL,NULL,'2024-10-23 02:12:23','2024-10-23 02:12:23'),(18,2,NULL,NULL,NULL,3,'2024-10-23 02:30:00',NULL,NULL,'2024-10-23 02:30:22','2024-10-23 02:30:22'),(19,2,NULL,NULL,NULL,3,'2024-10-23 02:30:00',NULL,NULL,'2024-10-23 02:30:22','2024-10-23 02:30:22'),(21,2,NULL,NULL,NULL,3,'2024-10-23 02:30:00',NULL,NULL,'2024-10-23 02:31:10','2024-10-23 02:31:10'),(22,1,NULL,NULL,NULL,2,'2024-10-23 03:01:00',NULL,NULL,'2024-10-23 03:00:20','2024-10-23 03:01:27'),(23,NULL,NULL,22,2,1,'2024-10-23 03:01:00',NULL,0,'2024-10-23 03:00:53','2024-10-23 03:01:06'),(24,NULL,NULL,22,2,1,'2024-10-23 03:01:00',NULL,0,'2024-10-23 03:01:09','2024-10-23 03:01:23'),(25,1,NULL,NULL,NULL,2,'2024-10-23 03:01:00',NULL,NULL,'2024-10-23 03:01:27','2024-10-23 03:01:27'),(26,NULL,NULL,25,2,1,'2024-10-23 03:01:00',NULL,NULL,'2024-10-23 03:01:27','2024-10-23 03:01:27'),(27,NULL,NULL,25,2,1,'2024-10-23 03:01:00',NULL,NULL,'2024-10-23 03:01:27','2024-10-23 03:01:27'),(29,2,NULL,NULL,NULL,3,'2024-10-23 02:30:00',NULL,NULL,'2024-10-23 03:02:37','2024-10-23 03:02:37'),(30,1,NULL,NULL,NULL,2,'2024-10-23 03:16:00',NULL,NULL,'2024-10-23 03:07:49','2024-10-23 03:16:30'),(31,NULL,NULL,30,2,1,'2024-10-23 03:08:00',NULL,0,'2024-10-23 03:08:00','2024-10-23 03:08:13'),(32,1,NULL,NULL,NULL,2,'2024-10-23 03:16:00',NULL,NULL,'2024-10-23 03:16:30','2024-10-23 03:16:30'),(33,NULL,NULL,32,2,1,'2024-10-23 03:08:00',NULL,NULL,'2024-10-23 03:16:30','2024-10-23 03:16:30'),(35,2,NULL,NULL,NULL,3,'2024-10-23 02:30:00',NULL,NULL,'2024-10-23 03:55:46','2024-10-23 03:55:46'),(36,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-23 18:45:54','2024-10-23 18:45:54'),(37,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-23 18:45:54','2024-10-23 18:45:54'),(38,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-23 18:46:37','2024-10-23 18:46:37'),(40,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-23 18:46:58','2024-10-23 18:46:58'),(44,NULL,NULL,3,2,1,'2024-10-23 19:06:00',NULL,NULL,'2024-10-23 19:06:27','2024-10-23 19:06:27'),(45,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 19:06:27','2024-10-23 19:06:27'),(46,NULL,NULL,45,2,1,'2024-10-23 19:06:00',NULL,NULL,'2024-10-23 19:06:27','2024-10-23 19:06:27'),(48,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 19:06:38','2024-10-23 19:06:38'),(58,NULL,NULL,3,2,1,'2024-10-23 19:08:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(59,NULL,NULL,3,2,1,'2024-10-23 19:08:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(60,NULL,NULL,3,2,1,'2024-10-23 19:09:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(61,NULL,NULL,3,2,1,'2024-10-23 19:09:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(62,NULL,NULL,3,2,1,'2024-10-23 19:10:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(63,NULL,NULL,3,2,1,'2024-10-23 19:12:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(64,NULL,NULL,3,2,1,'2024-10-23 19:11:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(65,NULL,NULL,3,2,1,'2024-10-23 19:12:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(66,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(67,NULL,NULL,66,2,1,'2024-10-23 19:06:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(68,NULL,NULL,66,2,1,'2024-10-23 19:08:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(69,NULL,NULL,66,2,1,'2024-10-23 19:08:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(70,NULL,NULL,66,2,1,'2024-10-23 19:09:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(71,NULL,NULL,66,2,1,'2024-10-23 19:09:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(72,NULL,NULL,66,2,1,'2024-10-23 19:10:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(73,NULL,NULL,66,2,1,'2024-10-23 19:12:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(74,NULL,NULL,66,2,1,'2024-10-23 19:11:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(75,NULL,NULL,66,2,1,'2024-10-23 19:12:00',NULL,NULL,'2024-10-23 19:12:36','2024-10-23 19:12:36'),(78,NULL,NULL,3,2,1,'2024-10-23 19:14:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(79,1,NULL,NULL,NULL,2,'2024-10-23 02:10:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(80,NULL,NULL,79,2,1,'2024-10-23 19:06:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(81,NULL,NULL,79,2,1,'2024-10-23 19:08:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(82,NULL,NULL,79,2,1,'2024-10-23 19:08:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(83,NULL,NULL,79,2,1,'2024-10-23 19:09:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(84,NULL,NULL,79,2,1,'2024-10-23 19:09:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(85,NULL,NULL,79,2,1,'2024-10-23 19:10:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(86,NULL,NULL,79,2,1,'2024-10-23 19:14:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(87,NULL,NULL,79,2,1,'2024-10-23 19:12:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(88,NULL,NULL,79,2,1,'2024-10-23 19:11:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(89,NULL,NULL,79,2,1,'2024-10-23 19:12:00',NULL,NULL,'2024-10-23 19:15:00','2024-10-23 19:15:00'),(91,1,NULL,NULL,NULL,2,'2024-10-23 03:01:00',NULL,NULL,'2024-10-23 19:25:32','2024-10-23 19:25:32'),(108,NULL,NULL,30,2,1,'2024-10-23 19:26:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(109,NULL,NULL,30,2,1,'2024-10-23 19:27:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(110,NULL,NULL,30,2,1,'2024-10-23 19:27:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(111,NULL,NULL,30,2,1,'2024-10-23 19:27:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(112,NULL,NULL,30,2,1,'2024-10-23 19:28:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(113,NULL,NULL,30,2,1,'2024-10-23 19:28:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(114,NULL,NULL,30,2,1,'2024-10-23 19:28:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(115,NULL,NULL,30,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(116,NULL,NULL,30,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(117,NULL,NULL,30,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(118,NULL,NULL,30,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(119,NULL,NULL,30,2,1,'2024-10-23 19:30:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(120,NULL,NULL,30,2,1,'2024-10-23 19:30:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(121,NULL,NULL,30,2,1,'2024-10-23 19:30:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(122,NULL,NULL,30,2,1,'2024-10-23 19:31:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(123,1,NULL,NULL,NULL,2,'2024-10-23 03:16:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(124,NULL,NULL,123,2,1,'2024-10-23 19:26:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(125,NULL,NULL,123,2,1,'2024-10-23 19:27:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(126,NULL,NULL,123,2,1,'2024-10-23 19:27:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(127,NULL,NULL,123,2,1,'2024-10-23 19:27:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(128,NULL,NULL,123,2,1,'2024-10-23 19:28:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(129,NULL,NULL,123,2,1,'2024-10-23 19:28:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(130,NULL,NULL,123,2,1,'2024-10-23 19:28:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(131,NULL,NULL,123,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(132,NULL,NULL,123,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(133,NULL,NULL,123,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(134,NULL,NULL,123,2,1,'2024-10-23 19:29:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(135,NULL,NULL,123,2,1,'2024-10-23 19:30:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(136,NULL,NULL,123,2,1,'2024-10-23 19:30:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(137,NULL,NULL,123,2,1,'2024-10-23 19:30:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(138,NULL,NULL,123,2,1,'2024-10-23 19:31:00',NULL,NULL,'2024-10-23 19:31:09','2024-10-23 19:31:09'),(148,NULL,NULL,22,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(149,NULL,NULL,22,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(150,NULL,NULL,22,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(151,NULL,NULL,22,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(152,NULL,NULL,22,2,1,'2024-10-23 19:33:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(153,NULL,NULL,22,2,1,'2024-10-23 19:33:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(154,NULL,NULL,22,2,1,'2024-10-23 19:34:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(155,NULL,NULL,22,2,1,'2024-10-23 19:34:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(156,1,NULL,NULL,NULL,2,'2024-10-23 03:01:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(157,NULL,NULL,156,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(158,NULL,NULL,156,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(159,NULL,NULL,156,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(160,NULL,NULL,156,2,1,'2024-10-23 19:32:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(161,NULL,NULL,156,2,1,'2024-10-23 19:33:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(162,NULL,NULL,156,2,1,'2024-10-23 19:33:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(163,NULL,NULL,156,2,1,'2024-10-23 19:34:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(164,NULL,NULL,156,2,1,'2024-10-23 19:34:00',NULL,NULL,'2024-10-23 19:35:25','2024-10-23 19:35:25'),(166,1,NULL,NULL,NULL,2,'2024-10-23 03:16:00',NULL,NULL,'2024-10-25 17:17:57','2024-10-25 17:17:57'),(167,1,NULL,NULL,NULL,2,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:18:37','2024-10-25 17:19:51'),(168,NULL,NULL,167,2,1,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:18:46','2024-10-25 17:19:04'),(169,NULL,NULL,167,2,1,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:19:07','2024-10-25 17:19:26'),(170,NULL,NULL,167,2,1,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:19:28','2024-10-25 17:19:46'),(171,1,NULL,NULL,NULL,2,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:19:51','2024-10-25 17:19:51'),(172,NULL,NULL,171,2,1,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:19:51','2024-10-25 17:19:51'),(173,NULL,NULL,171,2,1,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:19:51','2024-10-25 17:19:51'),(174,NULL,NULL,171,2,1,'2024-10-25 17:19:00',NULL,NULL,'2024-10-25 17:19:51','2024-10-25 17:19:51'),(175,1,NULL,NULL,NULL,2,'2024-10-25 17:23:00',NULL,NULL,'2024-10-25 17:20:35','2024-10-25 17:23:49'),(176,NULL,NULL,175,2,1,'2024-10-25 17:21:00',NULL,NULL,'2024-10-25 17:20:46','2024-10-25 17:21:11'),(177,NULL,NULL,175,2,1,'2024-10-25 17:21:00',NULL,NULL,'2024-10-25 17:21:17','2024-10-25 17:21:37'),(178,NULL,NULL,175,2,1,'2024-10-25 17:22:00',NULL,NULL,'2024-10-25 17:21:45','2024-10-25 17:22:19'),(179,NULL,NULL,175,2,1,'2024-10-25 17:22:00',NULL,NULL,'2024-10-25 17:22:26','2024-10-25 17:22:40'),(180,NULL,NULL,175,2,1,'2024-10-25 17:23:00',NULL,NULL,'2024-10-25 17:22:43','2024-10-25 17:23:14'),(181,NULL,NULL,175,2,1,'2024-10-25 17:23:00',NULL,NULL,'2024-10-25 17:23:20','2024-10-25 17:23:46'),(182,1,NULL,NULL,NULL,2,'2024-10-25 17:23:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(183,NULL,NULL,182,2,1,'2024-10-25 17:21:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(184,NULL,NULL,182,2,1,'2024-10-25 17:21:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(185,NULL,NULL,182,2,1,'2024-10-25 17:22:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(186,NULL,NULL,182,2,1,'2024-10-25 17:22:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(187,NULL,NULL,182,2,1,'2024-10-25 17:23:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(188,NULL,NULL,182,2,1,'2024-10-25 17:23:00',NULL,NULL,'2024-10-25 17:23:49','2024-10-25 17:23:49'),(189,4,NULL,NULL,NULL,3,'2024-10-25 19:53:00',NULL,NULL,'2024-10-25 19:53:58','2024-10-25 19:53:58'),(190,4,NULL,NULL,NULL,3,'2024-10-25 19:53:00',NULL,NULL,'2024-10-25 19:53:58','2024-10-25 19:53:58'),(192,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-25 23:18:34','2024-10-25 23:18:34'),(194,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-25 23:18:53','2024-10-25 23:18:53'),(196,4,NULL,NULL,NULL,3,'2024-10-25 19:53:00',NULL,NULL,'2024-10-25 23:19:52','2024-10-25 23:19:52'),(198,2,NULL,NULL,NULL,3,'2024-10-23 02:30:00',NULL,NULL,'2024-10-25 23:21:06','2024-10-25 23:21:06'),(199,5,NULL,NULL,NULL,3,'2024-10-26 00:12:00',NULL,NULL,'2024-10-26 00:12:14','2024-10-26 00:12:14'),(200,5,NULL,NULL,NULL,3,'2024-10-26 00:12:00',NULL,NULL,'2024-10-26 00:12:14','2024-10-26 00:12:14'),(202,5,NULL,NULL,NULL,3,'2024-10-26 00:12:00',NULL,NULL,'2024-10-26 00:13:29','2024-10-26 00:13:29'),(204,5,NULL,NULL,NULL,3,'2024-10-26 00:12:00',NULL,NULL,'2024-10-26 00:13:42','2024-10-26 00:13:42'),(206,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-26 00:50:46','2024-10-26 00:50:46'),(208,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-26 00:51:20','2024-10-26 00:51:20'),(210,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-26 00:52:04','2024-10-26 00:52:04'),(212,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-26 00:52:41','2024-10-26 00:52:41'),(214,3,NULL,NULL,NULL,3,'2024-10-23 18:45:00',NULL,NULL,'2024-10-26 00:54:36','2024-10-26 00:54:36');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES (2,1,1),(3,1,1),(5,1,1),(9,1,1),(15,1,1),(22,1,1),(25,1,1),(30,1,1),(32,1,1),(45,1,1),(48,1,1),(66,1,1),(79,1,1),(91,1,1),(123,1,1),(156,1,1),(166,1,1),(167,1,1),(171,1,1),(175,1,1),(182,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,'Item','item','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-10-23 02:08:19','2024-10-23 02:08:19',NULL,'6741bbf4-20a9-4560-9433-5f762a35f40f'),(2,2,'Menu Section','menuSection','pot-food','blue',1,'site',NULL,'',1,'site',NULL,1,'2024-10-23 02:09:24','2024-10-23 02:09:24',NULL,'7aaad26b-fd73-4038-a3e5-53b41b6683a9'),(3,3,'Text','text','text','indigo',1,'site',NULL,'',1,'site',NULL,1,'2024-10-23 02:30:18','2024-10-23 02:30:18',NULL,'179d9939-a1e1-460b-9ac7-8fd44d18526b');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"6d3ac905-08f4-484f-9509-a2fe6a0d5e0c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"3fa9fe56-302f-46ca-a269-152adb160e44\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-23T02:06:59+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"f865dbb8-bcf3-4e15-a2e0-9c282572df60\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"14c30556-d0d6-401d-bdf3-ca19441e5ef9\", \"required\": false, \"dateAdded\": \"2024-10-23T02:11:36+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"524df69c-fc97-4519-bde4-02426cc2155a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"1a4d943a-19e1-4852-bb5f-6dbc77b4fc34\", \"required\": false, \"dateAdded\": \"2024-10-23T19:02:33+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-23 02:08:19','2024-10-23 19:02:33',NULL,'50d011df-da68-40a0-b0c7-2ee3891c182e'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"d079a896-74e1-44d1-8790-86bff389010a\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ae5c10f1-dc83-4e66-bcda-81a989cd2110\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-23T02:05:39+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"97790231-f908-4849-9a4e-335d4b223668\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2db746d3-58af-43ef-8a84-d32b282b3e82\", \"required\": false, \"dateAdded\": \"2024-10-23T02:09:24+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-23 02:09:24','2024-10-23 02:09:24',NULL,'bc4a3964-e809-4fb2-879a-7c10f42e628a'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"8cd66ef3-38cd-4b08-ab04-f44e347250f4\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"d92a6000-6f4a-4b2e-9481-9178b0fa9c47\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-23T02:28:22+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"43d913df-7e6a-4100-9dd0-29f41e1afdea\", \"required\": false, \"dateAdded\": \"2024-10-23T02:30:18+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-23 02:30:18','2024-10-23 02:30:18',NULL,'6d54fcfc-9b62-4a74-870b-16b7422fcacb'),(4,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"834f6b7d-0efa-4565-8bd7-db50d24850a3\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c08f3943-bc17-49c9-b98e-4a3672fd2116\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-25T17:28:06+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-25 19:53:58','2024-10-25 19:53:58',NULL,'dbbedaa7-e25a-4ca6-8f11-a23383faef96');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,'Price (small)','priceSmall','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Money','{\"currency\":\"USD\",\"defaultValue\":null,\"max\":null,\"min\":0,\"showCurrency\":false,\"size\":null}','2024-10-23 02:09:01','2024-10-23 19:01:38',NULL,'14c30556-d0d6-401d-bdf3-ca19441e5ef9'),(2,'Item','item','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"entryTypes\":[\"6741bbf4-20a9-4560-9433-5f762a35f40f\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2024-10-23 02:09:16','2024-10-23 02:09:16',NULL,'2db746d3-58af-43ef-8a84-d32b282b3e82'),(3,'Text','text','global',NULL,NULL,0,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"ckeConfig\":\"ed9eaa32-adc4-4f85-9ca2-15791f283ed9\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-10-23 02:30:12','2024-10-23 02:30:12',NULL,'43d913df-7e6a-4100-9dd0-29f41e1afdea'),(4,'Price (large)','priceLarge','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Money','{\"currency\":\"USD\",\"defaultValue\":null,\"max\":null,\"min\":0,\"showCurrency\":true,\"size\":null}','2024-10-23 19:02:14','2024-10-23 19:02:14',NULL,'1a4d943a-19e1-4852-bb5f-6dbc77b4fc34');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'5.4.9','5.3.0.2',0,'dbwdmfsyoqzt','3@rnekenfuce','2024-10-22 23:54:39','2024-10-26 00:12:14','003e507d-ef13-4343-808b-4f9716a912d8');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','8d494e7e-c26b-493d-9f79-6a15ad0e4501'),(2,'craft','m221101_115859_create_entries_authors_table','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','634afefa-8ec1-48cf-b8ae-0c03ab68bf8e'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','9e1b36e7-e4ee-4953-ac7f-2df92636b9ac'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','9c098e7b-8b2b-4924-9cc9-64be4b288bfd'),(5,'craft','m230314_110309_add_authenticator_table','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','df7abd0a-ff61-4162-9a8c-8b8aae32f28f'),(6,'craft','m230314_111234_add_webauthn_table','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','716d8136-fd8a-43e7-9149-e714ec61268f'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','e7cdce08-16a0-4eaf-a1bb-bcd34c259b6a'),(8,'craft','m230511_000000_field_layout_configs','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','96d42d84-6f87-4539-81e0-f7ccb46121c5'),(9,'craft','m230511_215903_content_refactor','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','363f7e0c-53de-4e56-9454-4998c8fcc9c5'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','f4b1b54e-8038-4c21-a4d3-4fcccaaa13e3'),(11,'craft','m230524_000001_entry_type_icons','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','85a8bdd5-4a56-4ead-bdf7-96ef593241b7'),(12,'craft','m230524_000002_entry_type_colors','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','8c2c00a7-1bfc-491c-b7ea-4c97b6449b24'),(13,'craft','m230524_220029_global_entry_types','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','1260380e-f66f-40e5-b68d-b57a49029a5c'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','edf97409-7310-4fb8-97fd-e86bfef21735'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','2978f48f-b1eb-4fb7-8f8b-0810de51a4c2'),(16,'craft','m230616_173810_kill_field_groups','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','396d9e6f-85c1-4fd8-9eb6-bb1d6db6ecce'),(17,'craft','m230616_183820_remove_field_name_limit','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','f2ae1bec-a679-467e-b8b6-d891b44fb18e'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','ccf62297-26bb-48f4-9a50-e93e2b967da6'),(19,'craft','m230710_162700_element_activity','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','76728e7c-ab5b-47bd-a7f2-b62aecce5a0f'),(20,'craft','m230820_162023_fix_cache_id_type','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','4aa286f8-cf6c-45e1-a7df-e98ff0300f9a'),(21,'craft','m230826_094050_fix_session_id_type','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','6f00e325-3cc8-42a0-aa26-5556bc73e762'),(22,'craft','m230904_190356_address_fields','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','5bac1cec-4041-4a04-833c-6c684de8390f'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','db5f63f7-d565-458e-a6e1-5f094f0d03fe'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','b76a98b2-f69e-4dc3-bff9-e9567cc78c73'),(25,'craft','m231213_030600_element_bulk_ops','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','2a06702e-9aee-42a7-bdc4-fff3b890240c'),(26,'craft','m240129_150719_sites_language_amend_length','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','ad22d500-1385-4af8-9538-e95521c28470'),(27,'craft','m240206_035135_convert_json_columns','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','2a8d513d-579b-43b1-aaa1-0a59934baee7'),(28,'craft','m240207_182452_address_line_3','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','e784e63b-821e-4b4f-908d-31db51dde899'),(29,'craft','m240302_212719_solo_preview_targets','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','b93b81f7-296f-45f1-9dda-aa4090b77a89'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','9b959643-c7d1-4678-8373-06a72b95c87d'),(31,'craft','m240723_214330_drop_bulkop_fk','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','76bde559-9d9c-4d08-9d5f-c5ff0f013b31'),(32,'craft','m240731_053543_soft_delete_fields','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','fc5db04e-d30f-4f23-8947-49b6e67136d2'),(33,'craft','m240805_154041_sso_identities','2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-22 23:54:39','7b03b505-f685-4095-90bd-4569dcbefd04'),(34,'plugin:ckeditor','Install','2024-10-23 02:28:11','2024-10-23 02:28:11','2024-10-23 02:28:11','a25f5fb3-f807-4a44-9767-becd07dc5976'),(35,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-10-23 02:28:11','2024-10-23 02:28:11','2024-10-23 02:28:11','1818f8cf-5e16-43c0-b626-37bcd4bedfbb');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'ckeditor','4.3.1','3.0.0.0','2024-10-23 02:28:10','2024-10-23 02:28:10','2024-10-23 02:28:10','22a3f7d9-65c0-4430-b806-d4fa3173495a'),(2,'expanded-singles','3.0.1','1.0.0','2024-10-23 03:58:20','2024-10-23 03:58:20','2024-10-23 03:58:20','46022285-aad3-4f66-afe8-1bf23f9fe847');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.headingLevels.0','1'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.headingLevels.1','2'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.headingLevels.2','3'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.headingLevels.3','4'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.headingLevels.4','5'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.headingLevels.5','6'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.name','\"Simple\"'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.toolbar.0','\"heading\"'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.toolbar.1','\"|\"'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.toolbar.2','\"bold\"'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.toolbar.3','\"italic\"'),('ckeditor.configs.ed9eaa32-adc4-4f85-9ca2-15791f283ed9.toolbar.4','\"link\"'),('dateModified','1729899833'),('email.fromEmail','\"fultonchain@gmail.com\"'),('email.fromName','\"West Street Mini-Mart\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.color','\"indigo\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elementCondition','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.autocapitalize','true'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.autocomplete','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.autocorrect','true'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.class','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.dateAdded','\"2024-10-23T02:28:22+00:00\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.disabled','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.elementCondition','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.id','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.includeInCards','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.inputType','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.instructions','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.label','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.max','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.min','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.name','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.orientation','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.placeholder','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.providesThumbs','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.readonly','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.requirable','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.size','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.step','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.tip','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.title','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.uid','\"d92a6000-6f4a-4b2e-9481-9178b0fa9c47\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.userCondition','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.warning','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.0.width','100'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.dateAdded','\"2024-10-23T02:30:18+00:00\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.elementCondition','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.fieldUid','\"43d913df-7e6a-4100-9dd0-29f41e1afdea\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.handle','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.includeInCards','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.instructions','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.label','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.providesThumbs','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.required','false'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.tip','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.uid','\"ccc30ff8-d5b2-412e-a7f6-9dafa9edf118\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.userCondition','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.warning','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.elements.1.width','100'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.name','\"Content\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.uid','\"8cd66ef3-38cd-4b08-ab04-f44e347250f4\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.fieldLayouts.6d54fcfc-9b62-4a74-870b-16b7422fcacb.tabs.0.userCondition','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.handle','\"text\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.hasTitleField','true'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.icon','\"text\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.name','\"Text\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.showSlugField','true'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.showStatusField','true'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.slugTranslationKeyFormat','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.slugTranslationMethod','\"site\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.titleFormat','\"\"'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.titleTranslationKeyFormat','null'),('entryTypes.179d9939-a1e1-460b-9ac7-8fd44d18526b.titleTranslationMethod','\"site\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.color','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elementCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.autocapitalize','true'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.autocomplete','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.autocorrect','true'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.class','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.dateAdded','\"2024-10-23T02:06:59+00:00\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.disabled','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.elementCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.id','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.includeInCards','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.inputType','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.instructions','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.label','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.max','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.min','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.name','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.orientation','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.placeholder','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.providesThumbs','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.readonly','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.requirable','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.size','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.step','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.tip','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.title','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.uid','\"3fa9fe56-302f-46ca-a269-152adb160e44\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.userCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.warning','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.0.width','100'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.dateAdded','\"2024-10-23T02:11:36+00:00\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.elementCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.fieldUid','\"14c30556-d0d6-401d-bdf3-ca19441e5ef9\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.handle','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.includeInCards','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.instructions','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.label','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.providesThumbs','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.required','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.tip','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.uid','\"f865dbb8-bcf3-4e15-a2e0-9c282572df60\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.userCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.warning','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.1.width','100'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.dateAdded','\"2024-10-23T19:02:33+00:00\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.elementCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.fieldUid','\"1a4d943a-19e1-4852-bb5f-6dbc77b4fc34\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.handle','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.includeInCards','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.instructions','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.label','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.providesThumbs','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.required','false'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.tip','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.uid','\"524df69c-fc97-4519-bde4-02426cc2155a\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.userCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.warning','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.elements.2.width','100'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.name','\"Content\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.uid','\"6d3ac905-08f4-484f-9509-a2fe6a0d5e0c\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.fieldLayouts.50d011df-da68-40a0-b0c7-2ee3891c182e.tabs.0.userCondition','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.handle','\"item\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.hasTitleField','true'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.icon','\"\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.name','\"Item\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.showSlugField','true'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.showStatusField','true'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.slugTranslationKeyFormat','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.slugTranslationMethod','\"site\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.titleFormat','\"\"'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.titleTranslationKeyFormat','null'),('entryTypes.6741bbf4-20a9-4560-9433-5f762a35f40f.titleTranslationMethod','\"site\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.color','\"blue\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elementCondition','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.autocapitalize','true'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.autocomplete','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.autocorrect','true'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.class','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.dateAdded','\"2024-10-23T02:05:39+00:00\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.disabled','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.elementCondition','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.id','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.includeInCards','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.inputType','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.instructions','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.label','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.max','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.min','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.name','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.orientation','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.placeholder','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.providesThumbs','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.readonly','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.requirable','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.size','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.step','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.tip','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.title','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.uid','\"ae5c10f1-dc83-4e66-bcda-81a989cd2110\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.userCondition','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.warning','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.0.width','100'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.dateAdded','\"2024-10-23T02:09:24+00:00\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.elementCondition','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.fieldUid','\"2db746d3-58af-43ef-8a84-d32b282b3e82\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.handle','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.includeInCards','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.instructions','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.label','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.providesThumbs','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.required','false'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.tip','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.uid','\"97790231-f908-4849-9a4e-335d4b223668\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.userCondition','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.warning','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.elements.1.width','100'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.name','\"Content\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.uid','\"d079a896-74e1-44d1-8790-86bff389010a\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.fieldLayouts.bc4a3964-e809-4fb2-879a-7c10f42e628a.tabs.0.userCondition','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.handle','\"menuSection\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.hasTitleField','true'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.icon','\"pot-food\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.name','\"Menu Section\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.showSlugField','true'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.showStatusField','true'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.slugTranslationKeyFormat','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.slugTranslationMethod','\"site\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.titleFormat','\"\"'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.titleTranslationKeyFormat','null'),('entryTypes.7aaad26b-fd73-4038-a3e5-53b41b6683a9.titleTranslationMethod','\"site\"'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.columnSuffix','null'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.handle','\"priceSmall\"'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.instructions','null'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.name','\"Price (small)\"'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.searchable','false'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.settings.currency','\"USD\"'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.settings.defaultValue','null'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.settings.max','null'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.settings.min','0'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.settings.showCurrency','false'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.settings.size','null'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.translationKeyFormat','null'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.translationMethod','\"none\"'),('fields.14c30556-d0d6-401d-bdf3-ca19441e5ef9.type','\"craft\\\\fields\\\\Money\"'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.columnSuffix','null'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.handle','\"priceLarge\"'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.instructions','null'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.name','\"Price (large)\"'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.searchable','false'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.settings.currency','\"USD\"'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.settings.defaultValue','null'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.settings.max','null'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.settings.min','0'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.settings.showCurrency','true'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.settings.size','null'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.translationKeyFormat','null'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.translationMethod','\"none\"'),('fields.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34.type','\"craft\\\\fields\\\\Money\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.columnSuffix','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.handle','\"item\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.instructions','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.name','\"Item\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.searchable','false'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.createButtonLabel','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.entryTypes.0','\"6741bbf4-20a9-4560-9433-5f762a35f40f\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.includeTableView','false'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.maxEntries','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.minEntries','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.pageSize','50'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.propagationKeyFormat','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.propagationMethod','\"all\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.showCardsInGrid','false'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.settings.viewMode','\"cards\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.translationKeyFormat','null'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.translationMethod','\"site\"'),('fields.2db746d3-58af-43ef-8a84-d32b282b3e82.type','\"craft\\\\fields\\\\Matrix\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.columnSuffix','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.handle','\"text\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.instructions','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.name','\"Text\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.searchable','false'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.availableTransforms','\"\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.availableVolumes','\"\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.ckeConfig','\"ed9eaa32-adc4-4f85-9ca2-15791f283ed9\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.createButtonLabel','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.defaultTransform','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.enableSourceEditingForNonAdmins','false'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.purifierConfig','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.purifyHtml','true'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.showUnpermittedFiles','false'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.showUnpermittedVolumes','false'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.showWordCount','false'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.settings.wordLimit','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.translationKeyFormat','null'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.translationMethod','\"none\"'),('fields.43d913df-7e6a-4100-9dd0-29f41e1afdea.type','\"craft\\\\ckeditor\\\\Field\"'),('fs.assets.hasUrls','true'),('fs.assets.name','\"Assets\"'),('fs.assets.settings.path','\"/var/www/html/web/assets/images\"'),('fs.assets.type','\"craft\\\\fs\\\\Local\"'),('fs.assets.url','\"@web/assets/images\"'),('meta.__names__.024375ab-589c-4361-9f22-e4d75204d0ec','\"West Street Mini-Mart\"'),('meta.__names__.14c30556-d0d6-401d-bdf3-ca19441e5ef9','\"Price (small)\"'),('meta.__names__.179d9939-a1e1-460b-9ac7-8fd44d18526b','\"Text\"'),('meta.__names__.1a4d943a-19e1-4852-bb5f-6dbc77b4fc34','\"Price (large)\"'),('meta.__names__.1ea7a8d5-2482-496a-803d-cea497e4dd0b','\"About\"'),('meta.__names__.2db746d3-58af-43ef-8a84-d32b282b3e82','\"Item\"'),('meta.__names__.3d421dba-c01e-40a2-b9ad-4c39a95c3063','\"Site Images\"'),('meta.__names__.43d913df-7e6a-4100-9dd0-29f41e1afdea','\"Text\"'),('meta.__names__.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4','\"Menu\"'),('meta.__names__.6741bbf4-20a9-4560-9433-5f762a35f40f','\"Item\"'),('meta.__names__.7aaad26b-fd73-4038-a3e5-53b41b6683a9','\"Menu Section\"'),('meta.__names__.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c','\"Contact\"'),('meta.__names__.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d','\"Menu Index\"'),('meta.__names__.b775f620-e1ac-4e5e-af04-d5e30236f06f','\"West Street Mini-Mart\"'),('meta.__names__.da258016-b548-44a9-8611-155fb882a5ae','\"Home Page\"'),('meta.__names__.ed9eaa32-adc4-4f85-9ca2-15791f283ed9','\"Simple\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.expanded-singles.edition','\"standard\"'),('plugins.expanded-singles.enabled','true'),('plugins.expanded-singles.schemaVersion','\"1.0.0\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.defaultPlacement','\"end\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.enableVersioning','true'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.entryTypes.0','\"179d9939-a1e1-460b-9ac7-8fd44d18526b\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.handle','\"about\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.maxAuthors','1'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.name','\"About\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.propagationMethod','\"all\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.enabledByDefault','true'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.hasUrls','true'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.template','\"about.twig\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.uriFormat','\"about\"'),('sections.1ea7a8d5-2482-496a-803d-cea497e4dd0b.type','\"single\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.defaultPlacement','\"end\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.enableVersioning','true'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.entryTypes.0','\"7aaad26b-fd73-4038-a3e5-53b41b6683a9\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.handle','\"menu\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.maxAuthors','1'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.name','\"Menu\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.propagationMethod','\"all\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.enabledByDefault','true'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.hasUrls','true'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.template','\"menu/_entry.twig\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.uriFormat','\"menu/{slug}\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.structure.maxLevels','null'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.structure.uid','\"7f4b2843-a92a-42c2-bd92-56b17fae4287\"'),('sections.5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4.type','\"structure\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.defaultPlacement','\"end\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.enableVersioning','true'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.entryTypes.0','\"179d9939-a1e1-460b-9ac7-8fd44d18526b\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.handle','\"contact\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.maxAuthors','1'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.name','\"Contact\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.propagationMethod','\"all\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.enabledByDefault','true'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.hasUrls','true'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.template','\"contact.twig\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.uriFormat','\"contact\"'),('sections.8cc232b7-7cba-4eb7-ae32-8cf92418eb6c.type','\"single\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.defaultPlacement','\"end\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.enableVersioning','true'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.entryTypes.0','\"179d9939-a1e1-460b-9ac7-8fd44d18526b\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.handle','\"menuIndex\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.maxAuthors','1'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.name','\"Menu Index\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.propagationMethod','\"all\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.enabledByDefault','true'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.hasUrls','true'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.template','\"menu/index.twig\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.uriFormat','\"menu\"'),('sections.b3f00ec9-eea3-41c8-81f7-d7aa37becb9d.type','\"single\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.defaultPlacement','\"end\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.enableVersioning','true'),('sections.da258016-b548-44a9-8611-155fb882a5ae.entryTypes.0','\"179d9939-a1e1-460b-9ac7-8fd44d18526b\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.handle','\"homePage\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.maxAuthors','1'),('sections.da258016-b548-44a9-8611-155fb882a5ae.name','\"Home Page\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.propagationMethod','\"all\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.enabledByDefault','true'),('sections.da258016-b548-44a9-8611-155fb882a5ae.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.hasUrls','true'),('sections.da258016-b548-44a9-8611-155fb882a5ae.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.template','\"index.twig\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.siteSettings.024375ab-589c-4361-9f22-e4d75204d0ec.uriFormat','\"__home__\"'),('sections.da258016-b548-44a9-8611-155fb882a5ae.type','\"single\"'),('siteGroups.b775f620-e1ac-4e5e-af04-d5e30236f06f.name','\"West Street Mini-Mart\"'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.handle','\"default\"'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.hasUrls','true'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.language','\"en-US\"'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.name','\"West Street Mini-Mart\"'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.primary','true'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.siteGroup','\"b775f620-e1ac-4e5e-af04-d5e30236f06f\"'),('sites.024375ab-589c-4361-9f22-e4d75204d0ec.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"West Street Mini-Mart\"'),('system.schemaVersion','\"5.3.0.2\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.altTranslationKeyFormat','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.altTranslationMethod','\"none\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elementCondition','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.autocapitalize','true'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.autocomplete','false'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.autocorrect','true'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.class','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.dateAdded','\"2024-10-25T17:28:06+00:00\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.disabled','false'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.elementCondition','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.id','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.includeInCards','false'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.inputType','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.instructions','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.label','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.max','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.min','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.name','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.orientation','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.placeholder','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.providesThumbs','false'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.readonly','false'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.requirable','false'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.size','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.step','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.tip','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.title','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.uid','\"c08f3943-bc17-49c9-b98e-4a3672fd2116\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.userCondition','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.warning','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.elements.0.width','100'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.name','\"Content\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.uid','\"834f6b7d-0efa-4565-8bd7-db50d24850a3\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fieldLayouts.dbbedaa7-e25a-4ca6-8f11-a23383faef96.tabs.0.userCondition','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.fs','\"assets\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.handle','\"siteImages\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.name','\"Site Images\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.sortOrder','1'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.subpath','\"\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.titleTranslationKeyFormat','null'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.titleTranslationMethod','\"site\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.transformFs','\"\"'),('volumes.3d421dba-c01e-40a2-b9ad-4c39a95c3063.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,3,1,1,''),(2,3,1,2,'Applied “Draft 1”'),(3,8,1,1,NULL),(4,3,1,3,'Applied “Draft 1”'),(5,8,1,2,NULL),(6,14,1,1,NULL),(7,18,1,1,NULL),(8,18,1,2,'Applied “Draft 1”'),(9,22,1,1,''),(10,23,1,1,NULL),(11,24,1,1,NULL),(12,18,1,3,'Applied “Draft 1”'),(13,30,1,1,''),(14,31,1,1,NULL),(15,18,1,4,'Applied “Draft 1”'),(16,36,1,1,NULL),(17,36,1,2,NULL),(18,36,1,3,'Applied “Draft 1”'),(19,3,1,4,'Applied “Draft 1”'),(20,44,1,1,NULL),(21,3,1,5,'Applied “Draft 1”'),(22,3,1,6,'Applied “Draft 1”'),(23,44,1,2,NULL),(24,58,1,1,NULL),(25,59,1,1,NULL),(26,60,1,1,NULL),(27,61,1,1,NULL),(28,62,1,1,NULL),(29,63,1,1,NULL),(30,64,1,1,NULL),(31,65,1,1,NULL),(32,3,1,7,'Applied “Draft 1”'),(33,44,1,3,NULL),(34,58,1,2,NULL),(35,59,1,2,NULL),(36,60,1,2,NULL),(37,61,1,2,NULL),(38,62,1,2,NULL),(39,78,1,1,NULL),(40,63,1,2,NULL),(41,64,1,2,NULL),(42,65,1,2,NULL),(43,22,1,2,'Applied “Draft 1”'),(44,30,1,2,'Applied “Draft 1”'),(45,108,1,1,NULL),(46,109,1,1,NULL),(47,110,1,1,NULL),(48,111,1,1,NULL),(49,112,1,1,NULL),(50,113,1,1,NULL),(51,114,1,1,NULL),(52,115,1,1,NULL),(53,116,1,1,NULL),(54,117,1,1,NULL),(55,118,1,1,NULL),(56,119,1,1,NULL),(57,120,1,1,NULL),(58,121,1,1,NULL),(59,122,1,1,NULL),(60,22,1,3,'Applied “Draft 1”'),(61,148,1,1,NULL),(62,149,1,1,NULL),(63,150,1,1,NULL),(64,151,1,1,NULL),(65,152,1,1,NULL),(66,153,1,1,NULL),(67,154,1,1,NULL),(68,155,1,1,NULL),(69,30,1,3,'Applied “Draft 1”'),(70,167,1,1,''),(71,168,1,1,NULL),(72,169,1,1,NULL),(73,170,1,1,NULL),(74,175,1,1,''),(75,176,1,1,NULL),(76,177,1,1,NULL),(77,178,1,1,NULL),(78,179,1,1,NULL),(79,180,1,1,NULL),(80,181,1,1,NULL),(81,189,NULL,1,NULL),(82,36,1,4,'Applied “Draft 1”'),(83,36,1,5,'Applied “Draft 1”'),(84,189,1,2,'Applied “Draft 1”'),(85,18,1,5,'Applied “Draft 1”'),(86,199,NULL,1,NULL),(87,199,1,2,'Applied “Draft 1”'),(88,199,1,3,'Applied “Draft 1”'),(89,36,1,6,'Applied “Draft 1”'),(90,36,1,7,'Applied “Draft 1”'),(91,36,1,8,'Applied “Draft 1”'),(92,36,1,9,'Applied “Draft 1”'),(93,36,1,10,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' fultonchain gmail com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' fultonchain '),(2,'slug',0,1,' temp dboqyllwacewdrtlczbiyaivadxqlntecaly '),(2,'title',0,1,''),(3,'slug',0,1,' specialty '),(3,'title',0,1,' specialty '),(8,'slug',0,1,' mozz sticks '),(8,'title',0,1,' mozz sticks '),(14,'slug',0,1,' french fries '),(14,'title',0,1,' french fries '),(18,'slug',0,1,' menu index '),(18,'title',0,1,' our menu '),(22,'slug',0,1,' subs '),(22,'title',0,1,' subs '),(23,'slug',0,1,' turkey '),(23,'title',0,1,' turkey '),(24,'slug',0,1,' roast beef '),(24,'title',0,1,' roast beef '),(30,'slug',0,1,' hot sandwiches '),(30,'title',0,1,' deli meat cheese '),(31,'slug',0,1,' octopus '),(31,'title',0,1,' octopus '),(36,'slug',0,1,' contact '),(36,'title',0,1,' contact us '),(44,'slug',0,1,' chicken over rice '),(44,'title',0,1,' chicken over rice '),(58,'slug',0,1,' lamb over rice '),(58,'title',0,1,' lamb over rice '),(59,'slug',0,1,' chicken lamb '),(59,'title',0,1,' chicken lamb '),(60,'slug',0,1,' steak over rice '),(60,'title',0,1,' steak over rice '),(61,'slug',0,1,' fish over rice '),(61,'title',0,1,' fish over rice '),(62,'slug',0,1,' six pieces shrimp over rice '),(62,'title',0,1,' six pieces shrimp over rice '),(63,'slug',0,1,' cheesburger w fries '),(63,'title',0,1,' cheesburger w fries '),(64,'slug',0,1,' double cheesburger w fries '),(64,'title',0,1,' double cheesburger w fries '),(65,'slug',0,1,' cheese sticks 3 '),(65,'title',0,1,' cheese sticks 3 '),(78,'slug',0,1,' fish shrimp over rice '),(78,'title',0,1,' fish shrimp over rice '),(108,'slug',0,1,' turkey '),(108,'title',0,1,' turkey '),(109,'slug',0,1,' honey turkey '),(109,'title',0,1,' honey turkey '),(110,'slug',0,1,' cajun turkey '),(110,'title',0,1,' cajun turkey '),(111,'slug',0,1,' turkey pastrami '),(111,'title',0,1,' turkey pastrami '),(112,'slug',0,1,' roast beef '),(112,'title',0,1,' roast beef '),(113,'slug',0,1,' beef salami '),(113,'title',0,1,' beef salami '),(114,'slug',0,1,' beef pastrami '),(114,'title',0,1,' beef pastrami '),(115,'slug',0,1,' beef bolgna '),(115,'title',0,1,' beef bolgna '),(116,'slug',0,1,' buffalo chicken '),(116,'title',0,1,' buffalo chicken '),(117,'slug',0,1,' bbq chicken '),(117,'title',0,1,' bbq chicken '),(118,'slug',0,1,' cheese '),(118,'title',0,1,' cheese '),(119,'slug',0,1,' american '),(119,'title',0,1,' american '),(120,'slug',0,1,' provolone '),(120,'title',0,1,' provolone '),(121,'slug',0,1,' swiss '),(121,'title',0,1,' swiss '),(122,'slug',0,1,' pepper jack '),(122,'title',0,1,' pepper jack '),(148,'slug',0,1,' roll '),(148,'title',0,1,' roll '),(149,'slug',0,1,' small sub '),(149,'title',0,1,' small sub '),(150,'slug',0,1,' large sub '),(150,'title',0,1,' large sub '),(151,'slug',0,1,' add any meat '),(151,'title',0,1,' add any meat '),(152,'slug',0,1,' add any topping '),(152,'title',0,1,' add any topping '),(153,'slug',0,1,' buffalo chicken sub '),(153,'title',0,1,' buffalo chicken sub '),(154,'slug',0,1,' chooped cheese roll '),(154,'title',0,1,' chooped cheese roll '),(155,'slug',0,1,' philly cheese steak '),(155,'title',0,1,' philly cheese steak '),(167,'slug',0,1,' gyros '),(167,'title',0,1,' gyros '),(168,'slug',0,1,' chicken gyro '),(168,'title',0,1,' chicken gyro '),(169,'slug',0,1,' lamb gyro '),(169,'title',0,1,' lamb gyro '),(170,'slug',0,1,' chicken lamb gyro '),(170,'title',0,1,' chicken lamb gyro '),(175,'slug',0,1,' breakfast '),(175,'title',0,1,' breakfast '),(176,'slug',0,1,' turkey bacon egg cheese '),(176,'title',0,1,' turkey bacon egg cheese '),(177,'slug',0,1,' sausage egg cheese '),(177,'title',0,1,' sausage egg cheese '),(178,'slug',0,1,' meat your choice egg cheese '),(178,'title',0,1,' meat your choice egg cheese '),(179,'slug',0,1,' buttered roll '),(179,'title',0,1,' buttered roll '),(180,'slug',0,1,' roll or bagel w cream cheese '),(180,'title',0,1,' roll or bagel w cream cheese '),(181,'slug',0,1,' roll or bagel w ceam cheese jam '),(181,'title',0,1,' roll or bagel w ceam cheese jam '),(189,'slug',0,1,' about '),(189,'title',0,1,' about us '),(199,'slug',0,1,' home page '),(199,'title',0,1,' subs gyros more ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,1,'Menu','menu','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-23 02:09:56','2024-10-23 02:09:56',NULL,'5e0e970b-b2b5-4182-a31d-86cdc6ac5ab4'),(2,NULL,'Menu Index','menuIndex','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-23 02:30:22','2024-10-23 02:30:22',NULL,'b3f00ec9-eea3-41c8-81f7-d7aa37becb9d'),(3,NULL,'Contact','contact','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-23 18:45:54','2024-10-23 18:45:54',NULL,'8cc232b7-7cba-4eb7-ae32-8cf92418eb6c'),(4,NULL,'About','about','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-25 19:53:58','2024-10-25 19:53:58',NULL,'1ea7a8d5-2482-496a-803d-cea497e4dd0b'),(5,NULL,'Home Page','homePage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-26 00:12:14','2024-10-26 00:12:14',NULL,'da258016-b548-44a9-8611-155fb882a5ae');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES (1,2,1),(2,3,1),(3,3,1),(4,3,1),(5,3,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'menu/{slug}','menu/_entry.twig',1,'2024-10-23 02:09:56','2024-10-23 02:09:56','c576f8cd-f7a0-44b6-a64c-f2749d89198d'),(2,2,1,1,'menu','menu/index.twig',1,'2024-10-23 02:30:22','2024-10-23 02:30:22','ca73430b-8ea5-4729-b408-c7016cf05f6a'),(3,3,1,1,'contact','contact.twig',1,'2024-10-23 18:45:54','2024-10-23 18:45:54','e647ecef-1b1d-497b-a482-dc7b6f5cfe59'),(4,4,1,1,'about','about.twig',1,'2024-10-25 19:53:58','2024-10-25 19:53:58','aa696e53-1dff-4873-8a5f-fcdb5373ed8e'),(5,5,1,1,'__home__','index.twig',1,'2024-10-26 00:12:14','2024-10-26 00:12:14','ca5b86e2-6c9d-4c94-95a0-f109fd97cac4');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'West Street Mini-Mart','2024-10-22 23:54:39','2024-10-22 23:54:39',NULL,'b775f620-e1ac-4e5e-af04-d5e30236f06f');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','West Street Mini-Mart','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-10-22 23:54:39','2024-10-22 23:54:39',NULL,'024375ab-589c-4361-9f22-e4d75204d0ec');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,14,0,'2024-10-23 02:10:16','2024-10-25 17:24:04','e3daf3e4-467c-41da-8a95-3a2beef24f54'),(2,1,2,1,4,5,1,'2024-10-23 02:10:16','2024-10-25 17:24:04','115be5ce-10a4-4cfc-9698-977db0f0d11f'),(3,1,3,1,6,7,1,'2024-10-23 02:10:16','2024-10-25 17:24:04','7adb2f1d-eb42-433a-b23b-6a1e8e10a950'),(4,1,22,1,10,11,1,'2024-10-23 03:00:20','2024-10-25 17:24:04','1dab9294-f7de-4af6-94d8-3c3339b6ec96'),(5,1,30,1,8,9,1,'2024-10-23 03:07:49','2024-10-25 17:24:04','d9bbdfed-878f-4791-a098-da90283563b3'),(6,1,167,1,12,13,1,'2024-10-25 17:18:37','2024-10-25 17:24:04','71bb1f05-522f-45a6-b705-8dbaef8afa3f'),(7,1,175,1,2,3,1,'2024-10-25 17:20:35','2024-10-25 17:24:04','7bb6cfcf-9469-4c63-8496-0436b44eaced');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2024-10-23 02:09:56','2024-10-23 02:09:56',NULL,'7f4b2843-a92a-42c2-bd92-56b17fae4287');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'fultonchain',NULL,NULL,NULL,'fultonchain@gmail.com','$2y$13$0FMbigbxyayaYqNd2ALK1.xJIaPQaPQ2qOCx3BXF6iPnWWIgHVMPS','2024-10-25 23:46:35',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-10-22 23:54:39','2024-10-22 23:54:39','2024-10-25 23:46:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Site Images',NULL,'2024-10-25 19:53:58','2024-10-25 19:53:58','5628cf66-cc7a-4081-9718-cbff98a9dcb2');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,4,'Site Images','siteImages','assets','','','','site',NULL,'none',NULL,1,'2024-10-25 19:53:58','2024-10-25 19:53:58',NULL,'3d421dba-c01e-40a2-b9ad-4c39a95c3063');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-10-22 23:56:27','2024-10-22 23:56:27','53827e7c-9d39-4fbd-9775-cedb152607a9'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-10-22 23:56:27','2024-10-22 23:56:27','b1626847-5c66-4833-bb0f-24d95897d656');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'westdeli'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-26  1:06:38
